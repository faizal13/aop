package com.fullerton.amazon.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class AmazonService {
	private AmazonS3Client s3Client;

	private final Log logger = LogFactory.getLog(this.getClass());

	/**
	 * <p>
	 * Initialize aws client
	 * </p>
	 */
	public AmazonService(String accessKey, String secretKey) {
		AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		s3Client = new AmazonS3Client(credentials);
	}

	/**
	 * <p>
	 * Upload file in S3 and return the url of the uploaded file
	 * </p>
	 * 
	 * @param bucketName
	 * @param keyName
	 * @param file
	 * @return
	 */
	public String putObject(String bucketName, String keyName, File file) {
		s3Client.putObject(bucketName, keyName, file);

		return s3Client.getUrl("commmodeldocuments", keyName).toExternalForm();
	}

	/**
	 * <p>
	 * Fetch list of all images in a bucket
	 * </p>
	 * 
	 * @param folderName
	 *            should be absolute path
	 * @param bucketName
	 * @param keyName
	 * @return
	 * @throws IOException
	 */
	public List<String> fetchListOfImagesInS3(String bucketName, String folderName) throws Exception {
		List<String> downloadedFiles = new ArrayList<>();
		ObjectListing objectListing = s3Client.listObjects(bucketName);

		logger.info("ObjectListing is " + objectListing);

		// if object listing is not null then only try getting files from bucket
		if (objectListing != null) {

			List<S3ObjectSummary> objectSummaryList = objectListing.getObjectSummaries();
			logger.debug("Object Summary List is:" + objectSummaryList);

			for (S3ObjectSummary objectSummary : objectSummaryList) {

				String key = objectSummary.getKey();
				try {
					// if key does not end with / then it's a file
					if (!key.endsWith("/")) {
						logger.debug("Key is " + key);

						// get folders path only null pointer is possible maybe
						Path s3FilePath = Paths.get(key);
						Path parent = s3FilePath.getParent();
						// if the file is present at root path without any folders, then take the path as is
						Path s3FolderPath = parent == null ? s3FilePath : parent;
						Path curPath = Paths.get(folderName);

						// create folders on local file system first as per s3 structure if not exists
						Path resolvedPath = curPath.resolve(s3FolderPath);
						Files.createDirectories(resolvedPath);
						Path copyPath = Paths.get(folderName, key);

						// then copy files to ec2 instance
						try (S3ObjectInputStream s3ObjectInputStream = this.getObject(bucketName, key);) {
							Files.copy(s3ObjectInputStream, copyPath);
							logger.info("Copied File "+key+"to "+copyPath+" successfully");
							s3Client.deleteObject(bucketName, key);
							logger.info("Deleted File "+key+"from s3 bucket successfully");
							downloadedFiles.add(copyPath.toString());
						}

					}
				} catch (Exception e) {
					// just log the failed files
					logger.error("Exception while processing s3 object with path "+key, e);
				}
			}
		}

		return downloadedFiles;
	}

	/**
	 * <p>
	 * Get image from aws bucket
	 * </p>
	 * 
	 * @param bucketName
	 * @param keyName
	 * @return
	 */
	public S3ObjectInputStream getObject(String bucketName, String keyName) {
		S3Object s3Object = null;

		s3Object = s3Client.getObject(bucketName, keyName);

		return s3Object.getObjectContent();

	}

	/**
	 * <p>
	 * Get s3 url
	 * </p>
	 * 
	 * @param bucketName
	 * @param keyName
	 * @return
	 */
	public String getS3Url(String bucketName, String keyName) {
		return s3Client.getUrl(bucketName, keyName).toExternalForm();
	}

	public static void main(String[] args) throws Exception {
		/*
		 * AmazonService awsService = new AmazonService(null, null);
		 * awsService.fetchListOfImagesInS3(null, "883935");
		 */
		Path path = Paths.get("lead/home/xyz.txt");
		System.out.println(path.toString());
		Path parentPath = path.getParent();
		Path curPath = Paths.get("").toAbsolutePath();
		Path concatPath = curPath.resolve(parentPath);
		System.out.println("Concat Path is " + concatPath);
		Files.createDirectories(concatPath);
		System.out.println("Path is" + path.getParent());
	}

}