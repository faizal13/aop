package com.fullerton.uc.aspect;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.fullerton.uc.model.ApiCallLog;
import com.fullerton.uc.service.ApiLogService;
import com.fullerton.uc.utils.ApiCallResponse;
import com.fullerton.uc.utils.RequestConfiguration;

@Aspect
@Component
public class ApiLoggingAspect {

	@Autowired
	private ApiLogService apiLogService;

	private static final Logger logger = LogManager.getLogger(ApiLoggingAspect.class);

	@SuppressWarnings("unchecked")
	@Around("com.fullerton.uc.pointcut.GlobalPointCuts.checkApiRequest()")
	public ApiCallResponse logGatewayRequests(ProceedingJoinPoint jointPoint) throws Throwable {

		Exception ex = null;
		String methodName = jointPoint.getSignature().getName();
		String url = null;
		String requestBody = null;
		String headers = null;
		RequestConfiguration reqConfiguration = null;
		String requestConfigString = null;
		String apiName = null;

		Object[] args = jointPoint.getArgs();

		// only log if the api call needs to be logged
		boolean loggable = false;

		if (Objects.nonNull(args)) {

			url = (String) args[0];
			
			apiName = (String) args[4];
			loggable = (boolean) args[5];

			if (loggable) {
				
				String loggedInUser = getLoggedInUsername();
				logger.info("**********Logged in user is :"+loggedInUser);
				
				// request will always contain url but others can be optionally null

				// if get request then get param map else get request body
				// avoid classcast exception by null check
				if (methodName.contains("get")) {
					requestBody = ((Map<String, String>) args[1]).toString();
				} else {
					requestBody = (String) args[1];
				}
				// simply save request headers in a string
				headers = ((Map<String, String>) args[2]).toString();
				reqConfiguration = (RequestConfiguration) args[3];
				requestConfigString = reqConfiguration.toString();
			}
		}
		logger.info("<<<<<<<< Executing " + methodName);

		ApiCallResponse response = null;

		// Log execution time using java 8
		LocalDateTime startDateTime = LocalDateTime.now();
		Long startTime = Instant.now().toEpochMilli();

		try {
			response = (ApiCallResponse) jointPoint.proceed();
			String stringResponse = response.getResponseBody();
			logger.info("Response from " + url + " is " + stringResponse);
		} catch (Exception e) {
			logger.info("****Error AROUND method " + methodName, e);
			ex = e;
		}

		Long endTime = Instant.now().toEpochMilli();
		Long executionTime = endTime - startTime;
		logger.info("Api request with " + methodName + "and " + url + " which started" + startDateTime + " finished in "
				+ executionTime + " milliseconds");

		// asynchronously save request log
		ApiCallLog apiLog = null;
		if (loggable) {
			apiLog = new ApiCallLog();
			apiLog.setRequestMethod(methodName);
			apiLog.setRequestUrl(url);
			apiLog.setCreatedOn(startDateTime);
			apiLog.setExecutionTime(executionTime);
			apiLog.setRequestHeaders(headers);
			apiLog.setRequestBody(requestBody);
			apiLog.setRequestConfig(requestConfigString);
			apiLog.setApiName(apiName);
			apiLog.setUserName(getLoggedInUsername());
			if (Objects.nonNull(response)) {
				apiLog.setResponseStatusCode(response.getStatusCode());
				apiLog.setResponseBody(response.getResponseBody());
				apiLog.setResponseHeaders(response.getHeaders());
			}
		}
		boolean exception = false;

		// then throw exception
		if (Objects.nonNull(ex)) {
			exception = true;

			if (loggable) {
				apiLog.setException(ex.getMessage());
			}
		}
		if (loggable) {
			apiLogService.logApiCallDetails(apiLog);
		}

		if (exception) {
			throw ex;
		}

		return response;

	}
	
	private String getLoggedInUsername (){
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    	
    	return ((UserDetails)auth.getPrincipal()).getUsername();
    }
}