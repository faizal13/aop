package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class UANValidator implements Validator {

	@Autowired
	private GenericValidations validations;
	
	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		int uanNoOfDigits = validations.getUanMaxDigits();
		String uanRegex = validations.getUanRegex();
		
		if(obj != null) {
			String uan = (String)obj;
			
			if(!StringUtils.isEmpty(uan) && !uan.matches(uanRegex)) {
				errors.rejectValue(null, "Only "+uanNoOfDigits+ "digits numeric value is allowed in UAN No.");
			}
		}

	}

}
