package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantPersonalInfoValidations;
import com.fullerton.uc.model.BreOneRequest;

@Component
public class BreOneRequestValidator implements Validator{
	
	@Autowired
	private ApplicantPersonalInfoValidations validations;

	@Override
	public boolean supports(Class<?> clazz) {
		return BreOneRequest.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if (obj != null && obj instanceof BreOneRequest) {
			
			BreOneRequest request = (BreOneRequest)obj;
			
			String appId = request.getApplicationId();
			String refNoRegex = validations.getRefNoRegex();
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicationId", "applicationId is required!");
			
			if (!StringUtils.isEmpty(appId) && !appId.matches(refNoRegex)) {
				errors.rejectValue("applicationId", "Incorrect applicationId. Only numbers are allowed!");
			}
		}
		
	}

	

}