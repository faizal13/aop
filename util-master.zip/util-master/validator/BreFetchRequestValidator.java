package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantPersonalInfoValidations;
import com.fullerton.uc.model.BreFechRequest;

@Component
public class BreFetchRequestValidator  implements Validator{
	
	@Autowired
	private ApplicantPersonalInfoValidations validations;

	@Override
	public boolean supports(Class<?> clazz) {
		return BreFechRequest.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if (obj != null && obj instanceof BreFechRequest) {
			
			BreFechRequest request = (BreFechRequest)obj;
			
			String appId = request.getApplicationId();
			String breId = request.getBreId();
			String refNoRegex = validations.getRefNoRegex();
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicationId", "applicationId is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "breId", "breId is required!");
			
			if (!StringUtils.isEmpty(appId) && !appId.matches(refNoRegex)) {
				errors.rejectValue("applicationId", "Incorrect applicationId. Only numbers are allowed!");
			}
			
			if (!StringUtils.isEmpty(breId) && !breId.matches(refNoRegex)) {
				errors.rejectValue("breId", "Incorrect breId. Only numbers are allowed!");
			}
		}
		
	}

	

}
