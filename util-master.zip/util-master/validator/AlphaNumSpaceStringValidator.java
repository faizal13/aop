package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class AlphaNumSpaceStringValidator implements Validator {
	
	@Autowired
	private GenericValidations genericValidations;

	@Override
	public boolean supports(Class<?> arg0) {
		return String.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if(obj != null) {
			
			String string = (String)obj;
			String alphanumRegex = genericValidations.getAlphaNumSpaceRegex();
			
			if(!string.matches(alphanumRegex)) {
				errors.rejectValue(null, "Only aplhanumeric string with spaces is allowed in "+errors.getObjectName());
			}
		}
		
	}

}
