package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.fullerton.uc.model.KarzaUanRequest;

@Component
public class KarzaUanRequestValidator implements Validator
{
	
	@Autowired
	private MobileNoValidator mobileNoValidator;
	
	@Autowired
	private OtpValidator otpValidator;
	
	@Override
	public boolean supports(Class<?> className) {
		return KarzaUanRequest.class.isAssignableFrom(className);
	}
	
	@Override
	public void validate(Object obj, Errors errors) 
	{
		
		if (obj != null) {
			KarzaUanRequest karzaUanRequest = (KarzaUanRequest) obj;
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "otp", "Please provide otp!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "request_id", "Please provide request_id!");
            String otp = karzaUanRequest.getOtp();
            String requestid = karzaUanRequest.getRequest_id();
		
            if ( !StringUtils.isEmpty(otp)) {
				errors.pushNestedPath("otp");
				ValidationUtils.invokeValidator(otpValidator, otp, errors);
				errors.popNestedPath();
			}
      
			}	

		}

}
