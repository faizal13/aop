package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantResidenceDetailsValidations;
import com.fullerton.uc.model.ResidenceAddress;
import com.fullerton.uc.model.ResidenceType;
import com.fullerton.uc.model.UserDetail;

@Component
public class ApplicantResidenceDetailsValidator implements Validator {

	//private static final Logger log = LoggerFactory.getLogger(ApplicantResidenceDetailsValidator.class);
	private Logger log = LogManager.getLogger(this.getClass());
	
	@Autowired
	private ApplicantResidenceDetailsValidations validations;

	@Autowired
	private ResidenceAddressValidator residenceAddressValidator;

	@Autowired
	private IdValidator idValidator;

	@Override
	public boolean supports(Class<?> className) {
		return UserDetail.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		log.warn("Inside residence details validator");

		if (obj != null && obj instanceof UserDetail) {
			UserDetail userDetail = (UserDetail) obj;

			log.info("Validating Residence info details for :", userDetail);

			ValidationUtils.invokeValidator(idValidator, userDetail, errors);

			String livingSinceRegex = validations.getLivingSinceRegex();
			int maxLivingSinceDigits = validations.getMaxLivingSinceDigits();
			int minLivingYears = validations.getMinLivingYears();
			int maxLivingYears = validations.getMaxLivingYears();
			int minLivingMonths = validations.getMinLivingMonths();
			int maxLivingMonths = validations.getMaxLivingMonths();

			ResidenceAddress residenceAddress = userDetail.getResidenceAddress();
			ResidenceAddress permanentAddress = userDetail.getPermanentAddress();
			boolean isPermAddSame = userDetail.isPermAddSameAsRes();
			boolean isYearValid = false;

			// first do common validation on residence address
			if (residenceAddress == null) {
				errors.rejectValue("residenceAddress", "Residence address is required!");
			} else {

				// id is now mandatory
				if (residenceAddress.getId() == null) {
					errors.rejectValue("residenceAddress.id", "Residence address id is required!");
				}

				ResidenceType residenceType = residenceAddress.getResidenceType();

				errors.pushNestedPath("residenceAddress.residenceType");
				ValidationUtils.invokeValidator(idValidator, residenceType, errors);
				errors.popNestedPath();

				errors.pushNestedPath("residenceAddress");
				ValidationUtils.invokeValidator(residenceAddressValidator, residenceAddress, errors);
				errors.popNestedPath();

				String livingSinceYears = residenceAddress.getLivingSinceYears();
				int noOfYears = 0;
				if (StringUtils.isEmpty(livingSinceYears)) {
					errors.rejectValue("residenceAddress.livingSinceYears", "Living since years is required!");
				} else {
					if (!livingSinceYears.matches(livingSinceRegex)) {
						errors.rejectValue("residenceAddress.livingSinceYears",
								"Living since years should contain numeric values and max "+maxLivingSinceDigits+" digits only.");
					} else {
						try {
							noOfYears = Integer.parseInt(livingSinceYears);
							if (!(noOfYears >= minLivingYears && noOfYears <= maxLivingYears)) {
								errors.rejectValue("residenceAddress.livingSinceYears",
										"No of years should be between "+minLivingYears+" and "+maxLivingYears+"!");
							} else {
								isYearValid = true;
							}
						} catch (Exception e) {
							log.error("Error while validating livingSinceYears value:" + livingSinceYears
									+ " in residenceAddress:");
							log.error(residenceAddress.toString());
						}
					}
				}

				String livingSinceMonths = residenceAddress.getLivingSinceMonths();
				if (StringUtils.isEmpty(livingSinceMonths)) {
					errors.rejectValue("residenceAddress.livingSinceMonths", "Living since months is required!");
				} else {
					if (!livingSinceMonths.matches(livingSinceRegex)) {
						errors.rejectValue("residenceAddress.livingSinceMonths",
								"Living since months should contain numeric values max "+maxLivingSinceDigits+" digits only.");
					} else {
						try {
							int noOfMonths = Integer.parseInt(livingSinceMonths);
							// if no of years is invalid then months should be between
							if (isYearValid && noOfYears == 0 && noOfMonths == 0) {
								errors.rejectValue("residenceAddress.livingSinceMonths",
										"Both years and months cannot be 0.");
							} else {
								if (!(noOfMonths >= minLivingMonths && noOfMonths <= maxLivingMonths)) {
									errors.rejectValue("residenceAddress.livingSinceMonths",
											"No of months should be from " + minLivingMonths + " to " + maxLivingMonths
													+ ".");
								}
							}

						} catch (Exception e) {
							log.error("Error while validating livingSinceMonths value:" + livingSinceMonths
									+ " in residenceAddress:");
							log.error(residenceAddress.toString());
						}
					}
				}
			}

			// then perform validation on permanent address
			if (!isPermAddSame) {
				if (permanentAddress == null) {
					errors.rejectValue("permanentAddress", "Please provide permanent address");
				} else {

					errors.pushNestedPath("permanentAddress");
					ValidationUtils.invokeValidator(residenceAddressValidator, permanentAddress, errors);
					errors.popNestedPath();
				}
			}

		}

	}

}
