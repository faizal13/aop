package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class AlphaSpaceStringValidator implements Validator {

	@Autowired
	GenericValidations genericValidations;
	
	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null) {

			String string = (String) obj;
			String alphaSpaceRegex = genericValidations.getAlphaSpaceRegex();

			if (!string.matches(alphaSpaceRegex)) {
				errors.rejectValue(null,
						"Only aplhabets and space is allowed in " + errors.getObjectName());
			}
		}

	}

}
