package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantPersonalInfoValidations;
import com.fullerton.uc.model.FcuRequest;

@Component
public class FcuInitidateRequestValidator implements Validator{
	
	@Autowired
	private ApplicantPersonalInfoValidations validations;

	@Override
	public boolean supports(Class<?> clazz) {
		return FcuRequest.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if (obj != null && obj instanceof FcuRequest) {
			
			FcuRequest request = (FcuRequest)obj;
			
			String leadId = request.getLeadId();
			String refNoRegex = validations.getRefNoRegex();
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "leadId", "LeadId is required!");
			
			if (!StringUtils.isEmpty(leadId) && !leadId.matches(refNoRegex)) {
				errors.rejectValue("leadId", "Incorrect LeadId. Only numbers are allowed!");
			}
		}
		
	}

	

}
