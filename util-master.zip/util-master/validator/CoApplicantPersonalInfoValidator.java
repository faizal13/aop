package com.fullerton.uc.validator;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.model.Application;
import com.fullerton.uc.model.CoapplicantType;
import com.fullerton.uc.model.Relationship;
import com.fullerton.uc.model.UserDetail;

@Component
public class CoApplicantPersonalInfoValidator implements Validator {

	@Autowired
	private CommonUserDetailValidator commonValidator;

	@Autowired
	private IdValidator idValidator;

	@Override
	public boolean supports(Class<?> className) {
		return Application.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null && obj instanceof Application) {

			Application application = (Application) obj;
			
			Long appId = application.getId();
			
			if(Objects.isNull(appId)) {
				errors.rejectValue("id", "Application id is mandatory!");;
			}

			UserDetail coapplicant1 = application.getCoapplicant1();

			// check id based interdependent validation other than common validated ones
			// validate specific details
			if (Objects.nonNull(coapplicant1)) {
				CoapplicantType coapplicantType = coapplicant1.getCoapplicantType();
				errors.pushNestedPath("coapplicant1.coapplicantType");
				ValidationUtils.invokeValidator(idValidator, coapplicantType, errors);
				errors.popNestedPath();

				Relationship relationship = coapplicant1.getRelationship();
				errors.pushNestedPath("coapplicant1.relationship");
				ValidationUtils.invokeValidator(idValidator, relationship, errors);
				errors.popNestedPath();

				// pass the remaining things to userdetail validator
				errors.pushNestedPath("coapplicant1");
				ValidationUtils.invokeValidator(commonValidator, coapplicant1, errors);
				errors.popNestedPath();
			}
			else
            {
                errors.rejectValue("coapplicant1", "Please provide co-applicant details");
            }

		}

	}
}
