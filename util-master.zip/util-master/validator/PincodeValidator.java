package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class PincodeValidator implements Validator {
	
	@Autowired
	private GenericValidations validations;

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		String pincodeRegex = validations.getPincodeRegex();
		
		if(obj != null) {
			String pincode = (String) obj;
			
			if(!pincode.matches(pincodeRegex)) {
				errors.rejectValue(null, "Pincode can be of 6 digits only");
			}
			
		}

	}

}
