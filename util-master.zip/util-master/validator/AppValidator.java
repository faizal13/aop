package com.fullerton.uc.validator;


import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.model.Application;
import com.fullerton.uc.model.EmploymentDetails;
import com.fullerton.uc.model.UserDetail;


@Component
public class AppValidator implements Validator
{

	@Autowired
	private MobileNoValidator mobileValidator;

	@Autowired
	private EmailValidator emailValidator;
	
	@Autowired
	private AlphaNumSpaceStringValidator alphaNumSpaceStringValidator;

	@Override
	public boolean supports(Class<?> className) {

		return Application.class.isAssignableFrom(className);
	}


	@Override
	public void validate(Object obj, Errors errors) 
	{
		if (obj != null) 
		{
			int minNameLength = 1;
			int maxNameLength = 55;
			String nameRegex = "[a-zA-Z ]{" + minNameLength + "," + maxNameLength + "}";


		Application application = (Application) obj;

			UserDetail userDetail =	application.getApplicant();


			EmploymentDetails employmentDetails = userDetail.getEmploymentDetails();

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "Please provide Id!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "refNo", "Please provide Ref No Id!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.id", "Please provide Applicant Id!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.firstName", "First name is mandatory!");
			//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.middleName", "Middle name is mandatory!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.lastName", "Last name is mandatory!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.mobile", "Mobile No is mandatory!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.employmentDetails.firmName", "Firm Name is mandatory!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.employmentDetails.emailId", "Email Id is mandatory!");
			String noRegex = "[0-9]+";


			String id = String.valueOf(application.getId());

			String refno = application.getRefNo();
			
		
		
		String applicantid = String.valueOf(userDetail.getId());
            

			if(!StringUtils.isEmpty(id) && !id.matches(noRegex)) {
				errors.rejectValue("id", "Incorrect id. Only numbers are allowed!");
			}

			if(!StringUtils.isEmpty(refno) && !refno.matches(noRegex)) {
				errors.rejectValue("refNo", "Incorrect refNo. Only numbers are allowed!");
			}


			if(!StringUtils.isEmpty(applicantid) && !applicantid.matches(noRegex)) {
				errors.rejectValue("applicant.id", "Incorrect applicant. Only numbers are allowed!");
			}


			String firstName = userDetail.getFirstName();
			String lastName = userDetail.getLastName();
			String middleName = userDetail.getMiddleName();
			String mobileNo = userDetail.getMobile();

			if (!StringUtils.isEmpty(firstName) && !(firstName.matches(nameRegex))) {
				errors.rejectValue("applicant.firstName", "First name should contain only aplhabets and maximum " + maxNameLength
						+ " characters are allowed.");
			}

			if (!StringUtils.isEmpty(lastName) && !(lastName.matches(nameRegex))) {
				errors.rejectValue("applicant.lastName", "Last name should contain only aplhabets and maximum " + maxNameLength
						+ " characters are allowed.");
			}

			if (!StringUtils.isEmpty(middleName) && !(middleName.matches(nameRegex))) {
				errors.rejectValue("applicant.middleName", "Middle name should contain only aplhabets and maximum "
						+ maxNameLength + " characters are allowed.");
			}


			if (!StringUtils.isEmpty(mobileNo)) {
				errors.pushNestedPath("applicant.mobile");
				ValidationUtils.invokeValidator(mobileValidator, mobileNo, errors);
				errors.popNestedPath();
			}


			// String firmName = employmentDetails.getFirmName();
			
			String emailId = employmentDetails.getEmailId();
			
			// removing validations for now
			/*if (!StringUtils.isEmpty(firmName)) {
			errors.pushNestedPath("applicant.employmentDetails.firmName");
			ValidationUtils.invokeValidator(alphaNumSpaceStringValidator, firmName,
			errors); errors.popNestedPath(); }*/
			 
			
			
			if (!StringUtils.isEmpty(emailId)) {
				errors.pushNestedPath("applicant.employmentDetails.emailId");
				ValidationUtils.invokeValidator(emailValidator, emailId, errors);
				errors.popNestedPath();
			}
		}


	}

}