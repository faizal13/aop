@ControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {
	
	protected Logger adviceLogger = LogManager.getLogger(this.getClass());

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest webRequest) {
		
		BindingResult bindingResult = ex.getBindingResult();

		// add null check
		List<ApiFieldError> apiFieldErrors = bindingResult.getFieldErrors().stream()
				.map(fieldError -> new ApiFieldError(fieldError.getField(), fieldError.getCode(),
						fieldError.getRejectedValue()))
				.collect(Collectors.toList());

		List<ApiGlobalError> apiGlobalErrors = bindingResult.getGlobalErrors().stream()
				.map(globalError -> new ApiGlobalError(globalError.getCode())).collect(Collectors.toList());

		ApiErrorsView apiErrorsView = new ApiErrorsView(apiFieldErrors, apiGlobalErrors);
		FieldErrorResponse errorResponse = new FieldErrorResponse(apiErrorsView);
		
		HttpServletRequest request = ((ServletWebRequest)webRequest).getRequest();

//		FieldErrorResponse response = ResponseUtils.getFieldErrorResponse(30, "Field Validation Failed", apiErrorsView, request);
		CustomResponse<Object> response = ResponseUtils.getCustomResponse(30, errorResponse, "Field Validation Failed", request);
		
		adviceLogger.error("For request path:"+request.getServletPath());
		adviceLogger.error("Field errors are: "+apiErrorsView);
		
		// destroyLoggerVariables();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest webRequest) {

		adviceLogger.error("Bad Request recieved!", ex);
		int statusCode = 400;
		String description = "Bad Request. Please check the request and try again!";
		HttpServletRequest request = ((ServletWebRequest)webRequest).getRequest();
		CustomResponse<Object> customResponse = ResponseUtils.getCustomResponse(statusCode, new EmptyJsonResponse(), description, request);
		return new ResponseEntity<>(customResponse, HttpStatus.OK);
	}
	
}