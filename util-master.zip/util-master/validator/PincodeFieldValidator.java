package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.model.Pincode;

@Component
public class PincodeFieldValidator implements Validator {

	@Autowired
	private PincodeValidator pincodeValidator;

	@Override
	public boolean supports(Class<?> className) {
		return Pincode.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null && obj instanceof Pincode) {

			Pincode pincode = (Pincode) obj;
			String pincodeValue = pincode.getName();

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "pincode is empty!");

			if (!StringUtils.isEmpty(pincodeValue)) {
				errors.pushNestedPath("name");
				ValidationUtils.invokeValidator(pincodeValidator, pincodeValue, errors);
				errors.popNestedPath();
			}

		}

	}
}