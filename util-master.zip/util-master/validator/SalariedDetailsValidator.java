package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantEmploymentValidations;
import com.fullerton.uc.model.Designation;
import com.fullerton.uc.model.EmploymentDetails;

@Component
public class SalariedDetailsValidator implements Validator {

	// private static final Logger log = LoggerFactory.getLogger(SalariedDetailsValidator.class);
	private Logger log = LogManager.getLogger(this.getClass());
	
	@Autowired
	private ApplicantEmploymentValidations validations;

	@Autowired
	private IdValidator idValidator;

	@Autowired
	private CommonEmploymentDetailValidator commonValidator;

	@Autowired
	private UANValidator uanValidator;

	@Autowired
	private AlphaNumSpaceStringValidator alphaNumSpaceStringValidator;

	@Autowired
	private DateFormatValidator dateFormatValidator;

	@Override
	public boolean supports(Class<?> className) {
		return EmploymentDetails.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		if (obj != null) {

			int maxSalaryDigits = validations.getMaxSalaryDigits();
			String salaryRegex = validations.getSalaryRegex();
			String workingSinceRegex = validations.getWorkingSinceRegex();
			int workingSinceMaxDigits = validations.getWorkingSinceMaxDigits();
			int minWorkingYears = validations.getMinWorkingYears();
			int maxWorkingYears = validations.getMaxWorkingYears();
			int minWorkingMonths = validations.getMinWorkingMonths();
			int maxWorkingMonths = validations.getMaxWorkingMonths();

			EmploymentDetails employmentDetails = (EmploymentDetails) obj;
			
			// invoke common validator to perform common validations
			ValidationUtils.invokeValidator(commonValidator, employmentDetails, errors);

			Designation designation = employmentDetails.getDesignation();
			String grossSalary = employmentDetails.getGrossSalary();
			String netSalary = employmentDetails.getNetSalary();
			String additionalIncome = employmentDetails.getAdditionalIncome();
			String workingSinceMonths = employmentDetails.getWorkingSinceMonths();
			String workingSinceYears = employmentDetails.getWorkingSinceYears();
			String uan = employmentDetails.getUan();
			String epfoEmployerName = employmentDetails.getEpfoEmployerName();
			String epfoDOJ = employmentDetails.getEpfoDOJ();

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "grossSalary", "Gross Salary is required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "netSalary", "Net Salary is required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "workingSinceMonths", "Working Since Months is required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "workingSinceYears", "Working Since Years is required");
		//	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "uan", "Uan is required");
		//	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "epfoEmployerName", "epfoEmployerName is required");
		//	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "epfoDOJ", "epfoDOJ is required");

			// check designation
			errors.pushNestedPath("designation");
			ValidationUtils.invokeValidator(idValidator, designation, errors);
			errors.popNestedPath();

			// check gross salary, net salary, annual income
			if (!StringUtils.isEmpty(grossSalary) && !grossSalary.matches(salaryRegex)) {
				errors.rejectValue("grossSalary",
						"Gross salary can be max " + maxSalaryDigits + " digits and numeric only");
			}

			if (!StringUtils.isEmpty(netSalary) && !netSalary.matches(salaryRegex)) {
				errors.rejectValue("netSalary",
						"Net salary can be max " + maxSalaryDigits + " digits and numeric only");
			}

			if (!StringUtils.isEmpty(additionalIncome) && !additionalIncome.matches(salaryRegex)) {
				errors.rejectValue("additionalIncome",
						"Additional income can be max " + maxSalaryDigits + " digits and numeric only");
			}

			// reject if net salary is greater than gross salary
			if (!StringUtils.isEmpty(grossSalary) && !StringUtils.isEmpty(netSalary) && grossSalary.matches(salaryRegex)
					&& netSalary.matches(salaryRegex)) {
				long aGrossSal = Long.parseLong(grossSalary);
				long aNetSal = Long.parseLong(netSalary);
				if (aNetSal > aGrossSal) {
					errors.reject("Net Salary cannot be greater than Gross Salary");
				}
			}

			// uan no
			if (!StringUtils.isEmpty(uan)) {
			errors.pushNestedPath("uan");
			ValidationUtils.invokeValidator(uanValidator, uan, errors);
			errors.popNestedPath();
			}

			// epfo employer name
			/*if (!StringUtils.isEmpty(epfoEmployerName)) {
				errors.pushNestedPath("epfoEmployerName");
				ValidationUtils.invokeValidator(alphaNumSpaceStringValidator, epfoEmployerName, errors);
				errors.popNestedPath();
			}*/

			// epfo doj
			if (!StringUtils.isEmpty(epfoDOJ)) {
				errors.pushNestedPath("epfoDOJ");
				ValidationUtils.invokeValidator(dateFormatValidator, epfoDOJ, errors);
				errors.popNestedPath();
			}

			// working since years months
			int noOfYears = 0;
			boolean isYearValid = false;
			if (!StringUtils.isEmpty(workingSinceYears) && !workingSinceYears.matches(workingSinceRegex)) {
				errors.rejectValue("workingSinceYears",
						"Living since years should contain numeric values and max "+workingSinceMaxDigits+" digits only.");
			} else {
				try {
					noOfYears = Integer.parseInt(workingSinceYears);
					if (!(noOfYears >= minWorkingYears && noOfYears <= maxWorkingYears)) {
						errors.rejectValue("workingSinceYears", "No of years should be between "+minWorkingYears+" and "+maxWorkingYears+" 99!");
					} else {
						isYearValid = true;
					}
				} catch (Exception e) {
					log.error("Error while validating workingSinceYears value:" + workingSinceYears);
					log.error(e.toString());
				}
			}

			if (!StringUtils.isEmpty(workingSinceMonths) && !workingSinceMonths.matches(workingSinceRegex)) {
				errors.rejectValue("workingSinceMonths",
						"Working since months should contain numeric values and max "+workingSinceMaxDigits+" digits only.");
			} else {
				try {
					int noOfMonths = Integer.parseInt(workingSinceMonths);
					// if no of years is invalid then months should be between
					if (isYearValid && noOfYears == 0 && noOfMonths == 0) {
						errors.rejectValue("workingSinceMonths", "Both years and months cannot be 0.");
					} else {
						if (!(noOfMonths >= minWorkingMonths && noOfMonths <= maxWorkingMonths)) {
							errors.rejectValue("workingSinceMonths", "No of months should be from " + minWorkingMonths
									+ " to " + maxWorkingMonths + ".");
						}
					}

				} catch (Exception e) {
					log.error("Error while validating workingSinceMonths value:" + workingSinceMonths);
					log.error(e.toString());
				}
			}
		}
	}
}
