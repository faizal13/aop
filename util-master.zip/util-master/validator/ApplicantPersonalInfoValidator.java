package com.fullerton.uc.validator;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantPersonalInfoValidations;
import com.fullerton.uc.config.validation.GenericValidations;
import com.fullerton.uc.model.Application;
import com.fullerton.uc.model.Channel;
import com.fullerton.uc.model.Product;
import com.fullerton.uc.model.PropertyType;
import com.fullerton.uc.model.ResidenceAddress;
import com.fullerton.uc.model.ResidenceType;
import com.fullerton.uc.model.UserDetail;

@Component
public class ApplicantPersonalInfoValidator implements Validator {

	@Autowired
	private ApplicantPersonalInfoValidations validations;

	@Autowired
	private GenericValidations genericValidations;

	@Autowired
	private IdValidator idValidator;

	@Autowired
	private CommonUserDetailValidator userDetailValidator;

	@Autowired
	private AlphaSpaceStringValidator alphaSpaceValidator;

	@Autowired
	private PincodeValidator pincodeValidator;

	@Override
	public boolean supports(Class<?> className) {
		return Application.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null && obj instanceof Application) {
			Application application = (Application) obj;
			UserDetail userDetail = application.getApplicant();

			int tenureNoOfDigits = validations.getTenureNoOfDigits();

			// validator.applicant.tenure.maxdigits
			String tenureRegex = validations.getTenureRegex(); // validator.applicant.tenure.regex

			int minTenure = validations.getMinTenure(); // validator.applicant.tenure.min

			int maxTenure = validations.getMaxTenure(); // validator.applicant.tenure.max

			int reqAmntMinDigits = validations.getReqAmntMinDigits();
			int reqAmntMaxDigits = validations.getReqAmntMaxDigits();
			int minReqAmnt = validations.getMinReqAmnt();
			int maxReqAmt = validations.getMaxReqAmt();
			String requiredAmountRegex = validations.getRequiredAmountRegex();
			String refNoRegex = validations.getRefNoRegex();
			String alphaSpaceRegex = genericValidations.getAlphaSpaceRegex();

			// ask chitrali about refno field

			String tenure = application.getTenure();
			String requiredAmount = application.getRequiredAmount();
			String refNo = application.getRefNo();

			// SALES CITY AND SERVICING BRANCH VALIDATION
			String salesCity = application.getSalesCity();
			String servicingBranchName = application.getServicingBranchName();

			String channelNumregex = genericValidations.getChannelnumregex();
			// String channelASpaceRegex = genericValidation.getChannelspaceregex();
			int channelLength = genericValidations.getChannellength(); // 256

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "tenure", "Tenure is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "requiredAmount", "Please provide required amount!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "salesCity", "Please provide city name!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "servicingBranchName",
					"Please provide servicing branch name!");
		 
			

			if (!StringUtils.isEmpty(tenure)) {
				if (!tenure.matches(tenureRegex)) {
					errors.rejectValue("tenure", "Tenure should be numeric and will allow 3 digits");
				} else {
					int aTenure = Integer.parseInt(tenure);
					if (aTenure < minTenure || aTenure > maxTenure) {
						errors.rejectValue("tenure", "Tenure range should be from " + minTenure + " to " + maxTenure);
					}
				}
			}

			if (!StringUtils.isEmpty(requiredAmount)) {
				if (!requiredAmount.matches(requiredAmountRegex)) {
					errors.rejectValue("requiredAmount", "Required amount should be minimum " + reqAmntMinDigits
							+ " digits and max " + reqAmntMaxDigits + " numeric value only.");
				} else {
					int reqAmnt = Integer.parseInt(requiredAmount);
					if (reqAmnt < minReqAmnt || reqAmnt > maxReqAmt) {
						errors.rejectValue("requiredAmount",
								"Required amount should be from " + minReqAmnt + " to " + maxReqAmt);
					}
				}
			}

			if (!StringUtils.isEmpty(refNo) && !refNo.matches(refNoRegex)) {
				errors.rejectValue("refNo", "Incorrect refNo. Only numbers are allowed!");
			}

			Long appId = application.getId();
			if (appId != null) {
				if (Objects.isNull(userDetail) || userDetail.getId() == null) {
					errors.reject("Please provide user detail id in case of update");
				}
			} else {
				if (Objects.nonNull(userDetail) && userDetail.getId() != null) {
					errors.reject("User id is not allowed in case of new lead creation");
				}
			}

			// do applicant specific validations
			if (Objects.nonNull(userDetail)) {

				Long userDetailId = userDetail.getId();

				// move to applicant
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.sourcingDetailType",
						"Please provide sourcing type.");

				String sourcingDetailType = userDetail.getSourcingDetailType();

				Product product = userDetail.getProduct();
				PropertyType propertyType = userDetail.getPropertyType();
				ResidenceAddress residenceAddress = userDetail.getResidenceAddress();

				if (!StringUtils.isEmpty(sourcingDetailType)) {
					if (!sourcingDetailType.matches(alphaSpaceRegex)) {
						errors.rejectValue("applicant.sourcingDetailType",
								"SourcingDetailType should only contain alphabets and spaces.");
					} else if (sourcingDetailType.equalsIgnoreCase("channelSourcing"))
					{
						 ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.channel.code","please provide a valid channel");
						Channel channel = userDetail.getChannel();
						if (Objects.nonNull(channel)) {
							String channelCode = channel.getCode();

							if (channelCode.length() > channelLength) {

								errors.rejectValue("applicant.channel.code",
										"Maximum " + channelLength + " characters allowed in Channel Code");

							}

							else if (!channelCode.matches(channelNumregex)) {
								errors.rejectValue("applicant.channel.code", "Please provide a valid channel");
							}

							errors.pushNestedPath("applicant.channel");
							ValidationUtils.invokeValidator(idValidator, channel, errors);
							errors.popNestedPath();
							/*
							 * if (channel == null) { errors.rejectValue("channel", "Channel is required!");
							 * } else { Long id = channel.getId(); if (id == null) {
							 * errors.rejectValue("channel.id", "Channel id is required!"); } }
							 */
						}
					}
				}
				errors.pushNestedPath("applicant.product");
				ValidationUtils.invokeValidator(idValidator, product, errors);
				errors.popNestedPath();

				errors.pushNestedPath("applicant.propertyType");
				ValidationUtils.invokeValidator(idValidator, propertyType, errors);
				errors.popNestedPath();

				if (residenceAddress == null) {
					errors.rejectValue("applicant.residenceAddress", "Residence address is required!");
				} else {

					Long residenceId = residenceAddress.getId();
					if (userDetailId != null && residenceId == null) {
						errors.rejectValue("applicant.residenceAddress.id", "Residence address id is required!");
					}

					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.residenceAddress.pincodeValue",
							"PincodeValue is required!");
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.residenceAddress.state",
							"State is required!");
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.residenceAddress.cityValue",
							"CityValue is required!");
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicant.residenceAddress.district",
							"District is required!");

					String pincodeValue = residenceAddress.getPincodeValue();
					String cityValue = residenceAddress.getCityValue();
					String state = residenceAddress.getState();
					String district = residenceAddress.getDistrict();
					ResidenceType residenceType = residenceAddress.getResidenceType();

					if (!StringUtils.isEmpty(pincodeValue)) {
						errors.pushNestedPath("applicant.residenceAddress.pincodeValue");
						ValidationUtils.invokeValidator(pincodeValidator, pincodeValue, errors);
						errors.popNestedPath();
					}

					if (!StringUtils.isEmpty(cityValue)) {
						errors.pushNestedPath("applicant.residenceAddress.cityValue");
						ValidationUtils.invokeValidator(alphaSpaceValidator, cityValue, errors);
						errors.popNestedPath();
					}

					if (!StringUtils.isEmpty(state)) {
						errors.pushNestedPath("applicant.residenceAddress.state");
						ValidationUtils.invokeValidator(alphaSpaceValidator, state, errors);
						errors.popNestedPath();
					}

					if (!StringUtils.isEmpty(district)) {
						errors.pushNestedPath("applicant.residenceAddress.district");
						ValidationUtils.invokeValidator(alphaSpaceValidator, district, errors);
						errors.popNestedPath();
					}

					errors.pushNestedPath("applicant.residenceAddress.residenceType");
					ValidationUtils.invokeValidator(idValidator, residenceType, errors);
					errors.popNestedPath();

				}

			}

			errors.pushNestedPath("applicant");
			ValidationUtils.invokeValidator(userDetailValidator, userDetail, errors);
			errors.popNestedPath();

		}

	}

}
