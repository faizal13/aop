package com.fullerton.uc.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.model.MyleadRequest;

@Component
public class MyleadValidator implements Validator{

	@Override
	public boolean supports(Class<?> className) {
		return MyleadRequest.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		if (obj != null && obj instanceof MyleadRequest) {
			MyleadRequest mylead = (MyleadRequest) obj;
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type", "type is required!");
			List<String> statusList = new ArrayList<>();
			statusList.add("completed");
			statusList.add("pending");
			
			if (!StringUtils.isEmpty(mylead.getType())) {
				if(!statusList.contains(mylead.getType().toLowerCase().trim()))
				{
					errors.rejectValue("type", "Invalid type");
				}
			}
		}
		
	}

}
