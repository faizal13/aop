package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantPersonalInfoValidations;
import com.fullerton.uc.model.BeauroDetail;
import com.fullerton.uc.model.Gender;
import com.fullerton.uc.model.MarritalStatus;
import com.fullerton.uc.model.Qualification;
import com.fullerton.uc.model.UserDetail;
import com.fullerton.uc.settings.util.DateUtil;

@Component
public class CommonUserDetailValidator implements Validator {

	@Autowired
	private IdValidator idValidator;

	@Autowired
	private MobileNoValidator mobileValidator;

	@Autowired
	private EmailValidator emailValidator;

	@Autowired
	private BeauroDetailValidator beauroDetailValidator;

	@Autowired
	private DateFormatValidator dateFormatValidator;
	
	@Autowired
	private ApplicantPersonalInfoValidations personalInfoValidations;


	@Override
	public boolean supports(Class<?> className) {
		return UserDetail.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null) {

			// add validations for dob field

			UserDetail userDetail = (UserDetail) obj;

			int minNameLength = 1;
			int maxNameLength = 55;
			String nameRegex = "[a-zA-Z ]{" + minNameLength + "," + maxNameLength + "}";

			// validate common fields of applicant and co-applicant
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "First name is mandatory");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "Last name is mandatory");

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobile", "Mobile no is mandatory.");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "Email no is mandatory.");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dob", "Please provide date of birth.");

		

			
			Long userDetailId = userDetail.getId();
			String firstName = userDetail.getFirstName();
			String lastName = userDetail.getLastName();
			String middleName = userDetail.getMiddleName();
			String mobileNo = userDetail.getMobile();
			String email = userDetail.getEmail();
	    	String dob = userDetail.getDob();

			Gender gender = userDetail.getGender();
			MarritalStatus marritalStatus = userDetail.getMarritalStatus();

			// remove product and property type outside to applicant

			Qualification qualification = userDetail.getQualification();

			BeauroDetail beauroDetail = userDetail.getBeauroDetail();

			if (!StringUtils.isEmpty(firstName) && !(firstName.matches(nameRegex))) {
				errors.rejectValue("firstName", "First name should contain only aplhabets and maximum " + maxNameLength
						+ " characters are allowed.");
			}

			if (!StringUtils.isEmpty(lastName) && !(lastName.matches(nameRegex))) {
				errors.rejectValue("lastName", "Last name should contain only aplhabets and maximum " + maxNameLength
						+ " characters are allowed.");
			}

			if (!StringUtils.isEmpty(middleName) && !(middleName.matches(nameRegex))) {
				errors.rejectValue("middleName", "Middle name should contain only aplhabets and maximum "
						+ maxNameLength + " characters are allowed.");
			}

			if (!StringUtils.isEmpty(mobileNo)) {
				errors.pushNestedPath("mobile");
				ValidationUtils.invokeValidator(mobileValidator, mobileNo, errors);
				errors.popNestedPath();
			}

			if (!StringUtils.isEmpty(email)) {
				errors.pushNestedPath("email");
				ValidationUtils.invokeValidator(emailValidator, email, errors);
				errors.popNestedPath();
			}

			if (!StringUtils.isEmpty(dob)) {
				errors.pushNestedPath("dob");
				ValidationUtils.invokeValidator(dateFormatValidator, dob, errors);
				errors.popNestedPath();
			}

			// MASTER VALIDATION START
			errors.pushNestedPath("gender");
			ValidationUtils.invokeValidator(idValidator, gender, errors);
			errors.popNestedPath();

			errors.pushNestedPath("marritalStatus");
			ValidationUtils.invokeValidator(idValidator, marritalStatus, errors);
			errors.popNestedPath();

			errors.pushNestedPath("qualification");
			ValidationUtils.invokeValidator(idValidator, qualification, errors);
			errors.popNestedPath();
			// MASTER VALIDATION END

			if (beauroDetail == null) {
				errors.rejectValue("beauroDetail", "Please provide beauroDetails!");
			} else {
				// if userid is present then check beaurodetail is also present because
				// it means an update operation and beauro id should be mandatory
				Long beauroId = beauroDetail.getId();
				if ((userDetailId != null && beauroId == null) || (userDetailId == null && beauroId != null)) {
					errors.reject("Please provide both beauroDetail id and applicant id in case of update");
				} else {
					ValidationUtils.invokeValidator(beauroDetailValidator, userDetail, errors);
					
				}
			}

		}

	}

}
