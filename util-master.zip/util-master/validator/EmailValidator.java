package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class EmailValidator implements Validator {
	
	@Autowired
	private GenericValidations validations;

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if(obj != null) {
			
			String email = (String)obj;
			int maxEmailCharacters = validations.getMaxEmailCharacters();
			String emailRegex = validations.getEmailRegex();
			//String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$";
			
			if(email.length() > maxEmailCharacters) {
				errors.rejectValue(null,"Maximum "+maxEmailCharacters+" characters allowed in email");
			} else if(!email.matches(emailRegex)) {
				errors.rejectValue(null,"Please provide a valid email");
			}
		}

	}

}
