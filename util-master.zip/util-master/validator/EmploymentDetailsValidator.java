package com.fullerton.uc.validator;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.CoApplicantEmploymentValidations;
import com.fullerton.uc.model.EmploymentDetails;
import com.fullerton.uc.model.EmploymentType;
import com.fullerton.uc.model.ResidenceAddress;
import com.fullerton.uc.model.UserDetail;

@Component
public class EmploymentDetailsValidator implements Validator {

	private Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	private CoApplicantEmploymentValidations coApplicantValidations;

	@Autowired
	private IdValidator idValidator;

	@Autowired
	private ResidenceAddressValidator addressValidator;

	@Autowired
	private SalariedDetailsValidator salariedEmpValidator;

	@Autowired
	private SelfEmployedValidator selfEmployedValidator;

	@Override
	public boolean supports(Class<?> className) {
		return UserDetail.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		logger.info("****************Validating employment details!");

		if (obj != null) {

			UserDetail userDetails = (UserDetail) obj;

			// Common id validator works!!!
			ValidationUtils.invokeValidator(idValidator, userDetails, errors);

			// check if employment type is provided or not
			EmploymentType employmentType = userDetails.getEmploymentType();

			errors.pushNestedPath("employmentType");
			ValidationUtils.invokeValidator(idValidator, employmentType, errors);
			errors.popNestedPath();

			if (Objects.nonNull(employmentType)) {
				
				String name = employmentType.getName();
				
				// IGNORE VALIDATIONS IN CASE OF NON EARNING COAPPLICANT
				if (!StringUtils.isEmpty(name) && !name.equalsIgnoreCase(coApplicantValidations.getNonEarningCoApplicant())) {
					EmploymentDetails employmentDetails = userDetails.getEmploymentDetails();
					EmploymentDetails businessDetails = userDetails.getBusinessDetails();
					ResidenceAddress officeAddress = userDetails.getOfficeAddress();
					ResidenceAddress businessAddress = userDetails.getBusinessAddress();
					boolean empDetailPresent = Objects.nonNull(employmentDetails);
					boolean busDetailPresent = Objects.nonNull(businessDetails);
					boolean offAddPresent = Objects.nonNull(officeAddress);
					boolean busAddPresent = Objects.nonNull(businessAddress);
					// reject if both are provided in the request or incompatible key values
					// provided
					if ((empDetailPresent && busDetailPresent) || (offAddPresent && busAddPresent)) {
						errors.reject("Only one type of details/address is allowed.");
					} else if ((empDetailPresent && busAddPresent) || (busDetailPresent && offAddPresent)) {
						errors.reject(
								"Employment details - Office address combination or Business details - Business Address combination is allowed");
					} else {

						// check if one object is absent and other is present the reject
						if (!empDetailPresent && offAddPresent) {
							errors.rejectValue("employmentDetails", "Please provide employment details");
						}

						if (empDetailPresent && !offAddPresent) {
							errors.rejectValue("officeAddress", "Please provide office address");
						}

						if (!busDetailPresent && busAddPresent) {
							errors.rejectValue("businessDetails", "Please provide business details");
						}

						if (busDetailPresent && !busAddPresent) {
							errors.rejectValue("businessAddress", "Please provide business address");
						}

						if (empDetailPresent && offAddPresent) {
							Long empDetId = employmentDetails.getId();
							Long offAddId = officeAddress.getId();
							if ((Objects.nonNull(empDetId) && Objects.isNull(offAddId))
									|| (Objects.nonNull(offAddId) && Objects.isNull(empDetId))) {
								errors.reject(
										"Please provide both employment details id and office address id while updating.");
							}
						}

						if (busDetailPresent && busAddPresent) {
							Long busDetId = businessDetails.getId();
							Long busAddId = businessAddress.getId();
							if ((Objects.nonNull(busDetId) && Objects.isNull(busAddId))
									|| (Objects.nonNull(busAddId) && Objects.isNull(busDetId))) {
								errors.reject(
										"Please provide both business details id and business address id while updating.");
							}
						}

						if (offAddPresent) {
							errors.pushNestedPath("officeAddress");
							ValidationUtils.invokeValidator(addressValidator, officeAddress, errors);
							errors.popNestedPath();
						}

						if (busAddPresent) {
							errors.pushNestedPath("businessAddress");
							ValidationUtils.invokeValidator(addressValidator, businessAddress, errors);
							errors.popNestedPath();
						}

						if (empDetailPresent) {
							errors.pushNestedPath("employmentDetails");
							ValidationUtils.invokeValidator(salariedEmpValidator, employmentDetails, errors);
							errors.popNestedPath();
						}
						if (busDetailPresent) {
							errors.pushNestedPath("businessDetails");
							ValidationUtils.invokeValidator(selfEmployedValidator, businessDetails, errors);
							errors.popNestedPath();
						}
					} 
				} 
			}
		}

	}

}
