package com.fullerton.uc.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class OtpValidator implements Validator {

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if(obj != null) {
			String otp = (String)obj;
			int maxOtpDigits = 6;
			String OtpRegex = "^\\d{6}$";
			
			if(!otp.matches(OtpRegex)) {
				errors.rejectValue(null,"Invalid otp no. Should be "+maxOtpDigits+" digits only.");
			}
		}
	}

}
