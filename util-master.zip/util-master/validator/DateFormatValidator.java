package com.fullerton.uc.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class DateFormatValidator implements Validator {

	@Autowired
	private GenericValidations validations;
	
	private Logger dobValidLogger = LogManager.getLogger(this.getClass());

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null) 
		{
			String dateString = (String) obj;
			String dateFormat = validations.getDateFormat();
			String dateRegex = validations.getDateRegex();
			if (!StringUtils.isEmpty(dateString) && dateString.matches(dateRegex)) 
			{

				SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);
				// dont allow lenient values in date to pass trhough
				dateFormatter.setLenient(false);
				try {
					dateFormatter.parse(dateString);
				} 
				catch (ParseException e) 
				{
					dobValidLogger.error("Exception while parsing date:" + dateString);
					errors.rejectValue(null, "Incorrect date. Please provide correct date in " + dateFormat
							+ " dateFormat for " + errors.getObjectName());

				}
				
				
			} 
			
			else
			{
				errors.rejectValue(null, "Incorrect date. Please provide correct date in " + dateFormat
						+ " dateFormat for " + errors.getObjectName());
			}
		}

	}

}
