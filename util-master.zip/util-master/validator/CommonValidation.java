package com.fullerton.uc.validator;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Years;
import org.springframework.expression.ParseException;

public class CommonValidation {
	private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	public static boolean validateFields(String s, String pattern) {
		return s.matches(pattern) ? true : false;
	}

	public static boolean isUser18Older(DateTime userDob, int minimumAge) {
		/*
		 * DateTime minAge = new DateTime(); Days days = Days.daysBetween(userDob,
		 * minAge.minusYears(minimumAge));
		 * 
		 * return days.getDays()>=0 ;
		 */
		DateTime now = new DateTime();
		Years age = Years.yearsBetween(userDob, now);
		System.out.println("AGE" + age.getYears());
		if (age.getYears() >= minimumAge) {
			System.out.println("VALID AGE");
			return true;

		} else {
			return false;
		}
		// return age.getYears() >= minimumAge;

	}

	public static boolean validPan(String pan) {
		Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");

		Matcher matcher = pattern.matcher(pan);
		// Check if pattern matches
		if (matcher.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isValidDate(String inDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFormat.setLenient(false);

		try {
			dateFormat.parse(inDate.trim());
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public static boolean isAlphaNumeric(String s) {
		return s.matches("^[a-zA-Z0-9_]+$");
	}
	public static boolean isValidMasterSyncDate(String inDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);

		try {
			dateFormat.parse(inDate.trim());
		} catch (java.text.ParseException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}
}
