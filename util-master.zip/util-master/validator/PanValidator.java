package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.bean.PanRequest;

@Component
public class PanValidator implements Validator {
	
	@Autowired
	private PanNoValidator panNoValidator;

	@Override
	public boolean supports(Class<?> className) {
		
		return PanRequest.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if(obj != null) {
			PanRequest panRequest = (PanRequest)obj;
			
			String panNo = panRequest.getValue();
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "value", "PanNo is required!");
			
			if(!StringUtils.isEmpty(panNo)) {
				
				errors.pushNestedPath("value");
				ValidationUtils.invokeValidator(panNoValidator, panNo, errors);
				errors.popNestedPath();
				/*String regex = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
				
				if(!panNo.matches(regex)) {
					errors.rejectValue("name", "Invalid Pan No!");
				}*/
			}
		}

	}

}
