package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

import lombok.val;

@Component
public class LandlineValidator implements Validator {
	
	@Autowired
	private GenericValidations validations; 

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if(obj != null) {
			String landline = (String)obj;
			int maxLandlineDigits = validations.getMaxLandlineDigits();
			String landlineRegex = validations.getLandlineRegex();
			
			if(!landline.matches(landlineRegex)) {
				errors.rejectValue(null,"Invalid Landline no. Should be "+ maxLandlineDigits+" digits and numeric only and should not start with 0 or 1.");
			}
		}
	}

}
