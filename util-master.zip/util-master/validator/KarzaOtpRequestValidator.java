package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.fullerton.uc.model.KarzaOtpRequest;

@Component
public class KarzaOtpRequestValidator implements Validator
{
	@Autowired
	private UANValidator uANValidator;

	@Autowired
	private MobileNoValidator mobileNoValidator;

	@Override
	public boolean supports(Class<?> className) {
		return KarzaOtpRequest.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) 
	{
		
		if (obj != null) {
			KarzaOtpRequest karzaOtpRequest = (KarzaOtpRequest) obj;
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobile_no", "Please provide mobile!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "uan", "Please provide UAN!");
            String mobile = karzaOtpRequest.getMobile_no();
            String uan = karzaOtpRequest.getUan();
		
             if (!StringUtils.isEmpty(mobile)) {
				errors.pushNestedPath("mobile_no");
				ValidationUtils.invokeValidator(mobileNoValidator, mobile, errors);
				errors.popNestedPath();
			}
			
             if (!StringUtils.isEmpty(uan)) {
 				errors.pushNestedPath("uan");
 				ValidationUtils.invokeValidator(uANValidator, uan, errors);
 				errors.popNestedPath();
 			}
			}	

		}
	}

