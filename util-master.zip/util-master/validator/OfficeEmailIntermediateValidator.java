package com.fullerton.uc.validator;


import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.model.creditvidya.emaildomainverification.OfficeEmailIntermediate;


@Component
public class OfficeEmailIntermediateValidator implements Validator
{
	
	@Override
	public boolean supports(Class<?> className) {
		return OfficeEmailIntermediate.class.isAssignableFrom(className);
	}
	@Override
	public void validate(Object obj, Errors errors) 
	{
		
		if (obj != null) {
			OfficeEmailIntermediate  office = (OfficeEmailIntermediate) obj;
			
			   if (StringUtils.isEmpty(office.getUniqueId())) {
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "uniqueId", "Please provide unique Id!");
				}
			
			
			
			/*String uniqueId = officeEmailIntermediate.getUniqueId();
			
			String regx3 =  "^[0-9A-Za-z.]+@[A-Za-z0-9.]+\\.[A-Za-z]{2,6}$";
	        if (!StringUtils.isEmpty(uniqueId)) {
				 if (!uniqueId.matches(regx3)) {
					errors.rejectValue("uniqueId", "uniqueId should ve valid");
				}*/
			
	        
	        
		//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "status", "Please provide status!");
	//	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "message", "Please provide message!");
	
		
       // String status = officeEmailIntermediate.getStatus();
       // String message = officeEmailIntermediate.getMessage();
       
        
     //   String addressRegex = "[0-9a-zA-Z/ \\-]+";
       
    /*    String regex1 = "[a-zA-Z]+";
        
        String regex2 = "[0-9a-zA-Z]+";*/
        
       
     
        
       /* if (!StringUtils.isEmpty(message)) {
			 if (!status.matches(regex2)) {
				errors.rejectValue("message", "message should contain letters");
			}
		}*/
      
        
        
		}

		}

}
