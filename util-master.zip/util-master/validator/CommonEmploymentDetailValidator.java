package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantEmploymentValidations;
import com.fullerton.uc.model.EmploymentDetails;
import com.fullerton.uc.model.Organization;

@Component
public class CommonEmploymentDetailValidator implements Validator {

	@Autowired
	private ApplicantEmploymentValidations employmentValidations;
	
	@Autowired
	private IdValidator idValidator;

	@Autowired
	private MobileNoValidator mobileNoValidator;

	@Autowired
	private LandlineValidator landlineValidator;

	@Autowired
	private EmailValidator emailValidator;

	@Override
	public boolean supports(Class<?> className) {
		return EmploymentDetails.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		int firmNameMinLength = employmentValidations.getFirmNameMinLength();
		int firmNameMaxLength = employmentValidations.getFirmNameMaxLength();
		// String employerNameRegex = "[a-zA-Z0-9]{" + firmNameMinLength + "," + firmNameMaxLength + "}";*/

		if (obj != null) {
			EmploymentDetails employmentDetails = (EmploymentDetails) obj;

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firmName", "Business/EmployerName is required");

			String firmName = employmentDetails.getFirmName();
			String mobile = employmentDetails.getMobile();
			String landline = employmentDetails.getLandline();
			String emailId = employmentDetails.getEmailId();

			if (!StringUtils.isEmpty(firmName) && (firmName.length() < firmNameMinLength ||firmName.length() > firmNameMaxLength)) {
				errors.rejectValue("firmName", "Firmname should contain maximum "
						+ firmNameMaxLength + " characters");
			}

			Organization organization = employmentDetails.getOrganization();

			errors.pushNestedPath("organization");
			ValidationUtils.invokeValidator(idValidator, organization, errors);
			errors.popNestedPath();

			// email id
			if (!StringUtils.isEmpty(emailId)) {
				errors.pushNestedPath("emailId");
				ValidationUtils.invokeValidator(emailValidator, emailId, errors);
				errors.popNestedPath();
			}

			// either of these is mandatory
			if (StringUtils.isEmpty(mobile) && (StringUtils.isEmpty(landline))) {
				errors.reject("Please provide either landline or mobile no");
			}

			// mobile no
			if (!StringUtils.isEmpty(mobile)) {
				errors.pushNestedPath("mobile");
				ValidationUtils.invokeValidator(mobileNoValidator, mobile, errors);
				errors.popNestedPath();
			}

			// landline
			if (!StringUtils.isEmpty(landline)) {
				errors.pushNestedPath("landline");
				ValidationUtils.invokeValidator(landlineValidator, landline, errors);
				errors.popNestedPath();
			}

		}

	}

}
