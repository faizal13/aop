package com.fullerton.uc.validator;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import com.fullerton.uc.model.MasterSyncData;

@Service
public class MasterSyncValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

	@Override
	public void validate(Object target, Errors errors) {
		MasterSyncData obj = (MasterSyncData) target;
		if (obj != null) {
			if (!StringUtils.isBlank(obj.getLatestMasterSyncDate())) {
				if(!CommonValidation.isValidMasterSyncDate(obj.getLatestMasterSyncDate()))
				{
				errors.rejectValue("latestMasterSyncDate",
						"invalid latestMasterSyncDate format reuired yyyy-mm-dd hh:mm:ss",
						"latestMasterSyncDate is not valid");
			}
			}
		} else {
			errors.reject("request is empty!");
		}
	}

}