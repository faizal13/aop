package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.fullerton.uc.config.validation.GenericValidations;
import com.fullerton.uc.controller.ChannelRequest;

@Component
public class ChannelRequestValidator implements Validator {

	@Autowired
	private AlphaNumStringValidator alphanumValidator;

	@Autowired
	private GenericValidations genericValidation;

	@Override
	public boolean supports(Class<?> className) {
		return ChannelRequest.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null) {

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "code", "Please provide channel code");
			
			ChannelRequest channelRequest = (ChannelRequest) obj;
			String channelCode = channelRequest.getCode();

			String channelNumregex = genericValidation.getChannelnumregex();
			
			int channelLength = genericValidation.getChannellength(); // 256
               
			if (!StringUtils.isEmpty(channelCode)) {
				if (channelCode.length() > channelLength) {

					errors.rejectValue("code", "Maximum " + channelLength + " characters allowed in Channel Code");

				}

				else if (!channelCode.matches(channelNumregex)) {
					errors.rejectValue("code", "Please provide a valid channel");
				} 
			}
		}
		/*
		 * String channelCode = channelRequest.getCode();
		 * 
		 * if (!StringUtils.isEmpty(channelCode)) { errors.pushNestedPath("code");
		 * ValidationUtils.invokeValidator(alphanumValidator, channelCode, errors);
		 * errors.popNestedPath(); }
		 */

	}

}
