package com.fullerton.uc.validator;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.CoApplicantEmploymentValidations;
import com.fullerton.uc.model.BeauroDetail;
import com.fullerton.uc.model.Document;
import com.fullerton.uc.model.UserDetail;

@Component
public class BeauroDetailValidator implements Validator {

	@Autowired
	private AlphaSpaceStringValidator alphaSpaceValidator;

	@Autowired
	private IdValidator idValidator;

	@Autowired
	private PanNoValidator panNoValidator;

	@Autowired
	private CoApplicantEmploymentValidations coApplicantEmploymentValidations;

	@Override
	public boolean supports(Class<?> className) {
		return UserDetail.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "beauroDetail.documentNumber",
				"Please provide PAN No or Document No!");

		String regexforVoterId = coApplicantEmploymentValidations.getVoterIdRegex();
		String regexforPassport = coApplicantEmploymentValidations.getPassportNumberRegex();
		String voterId = coApplicantEmploymentValidations.getVoterId();
		String passport = coApplicantEmploymentValidations.getPassport();
		String license = coApplicantEmploymentValidations.getLicense();
		String licenseNumberRegex = coApplicantEmploymentValidations.getLicenseNumberRegex();

		if (obj != null) {
			UserDetail userDetail = (UserDetail) obj;
			BeauroDetail beauroDetail = userDetail.getBeauroDetail();
			if (Objects.nonNull(beauroDetail)) {
				// check pan details if pan available is true
				boolean panAvailable = beauroDetail.getPanAvailable();
				boolean panVerified = beauroDetail.getPanVerified();
				if (panAvailable) {
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "panNameAsPerNSDL",
							"Please provide pan name as per pan verification.");

					String panNameAsPerNSDL = userDetail.getPanNameAsPerNSDL();

					if (!StringUtils.isEmpty(panNameAsPerNSDL)) {
						errors.pushNestedPath("panNameAsPerNSDL");
						ValidationUtils.invokeValidator(alphaSpaceValidator, panNameAsPerNSDL, errors);
						errors.popNestedPath();
					}

					if (!panVerified) {
						errors.rejectValue("beauroDetail.panVerified", "Please verify pan.");
					}

				} else {

					// disallow pan verification in case of form 60
					if (panVerified) {
						errors.rejectValue("beauroDetail.panVerified",
								"Pan verification not allowed when choosing Form 60 validation");
					}

					if (Objects.nonNull(beauroDetail)) {
						Document document = beauroDetail.getDocument();
						if (Objects.nonNull(document)) {
							String code = document.getCode();
							String documentNumber = beauroDetail.getDocumentNumber();
							if (!StringUtils.isEmpty(code) && !StringUtils.isEmpty(documentNumber)) {
								if (code.equalsIgnoreCase(voterId) && !(documentNumber.matches(regexforVoterId))) {
									errors.rejectValue("beauroDetail.documentNumber",
											"Voter Id " + documentNumber + " is not valid.");

								} else if (code.equalsIgnoreCase(passport) && !(documentNumber.matches(regexforPassport))) {
									errors.rejectValue("beauroDetail.documentNumber",
											"Passport No " + documentNumber + " is not valid.");
								} else if (code.equalsIgnoreCase(license) && !(documentNumber.matches(licenseNumberRegex))) {
									errors.rejectValue("beauroDetail.documentNumber",
											"License No " + documentNumber + " is not valid.");
								}

							}
							errors.pushNestedPath("beauroDetail.document");
							ValidationUtils.invokeValidator(idValidator, document, errors);
							errors.popNestedPath();
						}
					}
				}

			}

		}
	}
}