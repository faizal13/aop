package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantEmploymentValidations;
import com.fullerton.uc.model.EmploymentDetails;
import com.fullerton.uc.model.NatureOfBusiness;

@Component
public class SelfEmployedValidator implements Validator {
	
	@Autowired
	private ApplicantEmploymentValidations validations;

	@Autowired
	private DateFormatValidator dateFormatValidator;

	@Autowired
	private IdValidator idValidator;

	@Autowired
	private CommonEmploymentDetailValidator commonValidator;

	@Override
	public boolean supports(Class<?> className) {
		return EmploymentDetails.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null) {

			EmploymentDetails employmentDetails = (EmploymentDetails) obj;

			// invoke common validator to perform common validations
			ValidationUtils.invokeValidator(commonValidator, employmentDetails, errors);

			int minAnnualPatDigits = validations.getMinAnnualPatDigits();
			int maxAnnualPatDigits = validations.getMaxAnnualPatDigits();
			String annualPatRegex = validations.getAnnualPatRegex();

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dateOfIncorporation",
					"Date of incorporation is mandatory.");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "annualPat", "Annual PAT is mandatory.");

			// nature of business validator
			NatureOfBusiness natureOfBusiness = employmentDetails.getNatureOfBusiness();

			errors.pushNestedPath("natureOfBusiness");
			ValidationUtils.invokeValidator(idValidator, natureOfBusiness, errors);
			errors.popNestedPath();

			// date of incorporation
			String dateOfIncorporation = employmentDetails.getDateOfIncorporation();
			if (!(StringUtils.isEmpty(dateOfIncorporation))) {
				errors.pushNestedPath("dateOfIncorporation");
				ValidationUtils.invokeValidator(dateFormatValidator, dateOfIncorporation, errors);
				errors.popNestedPath();
			}

			// annual pat
			String annualPat = employmentDetails.getAnnualPat();
			if (!(StringUtils.isEmpty(annualPat)) && !annualPat.matches(annualPatRegex)) {
				errors.rejectValue("annualPat", "Annual pat should be numeric and " + minAnnualPatDigits + " to "
						+ maxAnnualPatDigits + " digits.");
			}

		}

	}

}
