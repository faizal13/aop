package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class MobileNoValidator implements Validator {
	
	@Autowired
	private GenericValidations validations;

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if(obj != null) {
			String mobileNo = (String)obj;
			int maxMobileDigits = validations.getMaxMobileDigits();
			String mobileRegex = validations.getMobileNoRegex();
			
			if(!mobileNo.matches(mobileRegex)) {
				errors.rejectValue(null,"Invalid mobile no. Should be "+maxMobileDigits+" digits and numeric only and should not start from 0-5.");
			}
		}
	}

}
