package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.model.base.BaseModel;

@Component
public class IdValidator implements Validator {

	@Override
	public boolean supports(Class<?> className) {
		return BaseModel.class.isAssignableFrom(className);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void validate(Object obj, Errors errors) {
		
		// in case errors.pop get object name from stack
		// else get object name directly
		String objectName = errors.getNestedPath();
		if(StringUtils.isEmpty(objectName)) {
			objectName = errors.getObjectName();
		}
		
		if(obj == null) {
			errors.rejectValue(null, objectName +" is mandatory");
		} else {
			BaseModel baseModel = (BaseModel)obj;
			Long id = (Long) baseModel.getId();
			if(id == null) {
				errors.rejectValue("id", objectName+ "id is required");
			}
		}

	}

}
