package com.fullerton.uc.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.GenericValidations;

@Component
public class PanNoValidator implements Validator {
	
	@Autowired
	private GenericValidations validations;

	@Override
	public boolean supports(Class<?> className) {
		return String.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		if(obj != null) {
			String panNo = (String)obj;
			
			if(!panNo.matches(validations.getPanRegex())) {
				errors.rejectValue(null,"Please provide a valid 10 digit pan no!");
			}
		}

	}

}
