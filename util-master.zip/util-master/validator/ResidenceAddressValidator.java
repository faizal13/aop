package com.fullerton.uc.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fullerton.uc.config.validation.ApplicantResidenceDetailsValidations;
import com.fullerton.uc.model.ResidenceAddress;

@Component
public class ResidenceAddressValidator implements Validator {
	
	@Autowired
	private ApplicantResidenceDetailsValidations validations;

	@Autowired
	private PincodeValidator pincodeValidator;

	@Autowired
	private AlphaSpaceStringValidator alphaSpaceValidator;

	@Override
	public boolean supports(Class<?> className) {
		return ResidenceAddress.class.isAssignableFrom(className);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		if (obj != null && obj instanceof ResidenceAddress) {
			ResidenceAddress residenceAddress = (ResidenceAddress) obj;
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address1", "AddressLine1 is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address2", "AddressLine2 is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address3", "AddressLine3 is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "landmark", "Landmark is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pincodeValue", "PincodeValue is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "state", "State is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cityValue", "CityValue is required!");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "district", "District is required!");

			String address1 = residenceAddress.getAddress1();
			String address2 = residenceAddress.getAddress2();
			String address3 = residenceAddress.getAddress3();
			String addressRegex = validations.getAddressRegex();
			String landmark = residenceAddress.getLandmark();
			String pincodeValue = residenceAddress.getPincodeValue();
			String cityValue = residenceAddress.getCityValue();
			String state = residenceAddress.getState();
			String district = residenceAddress.getDistrict();
			int maxAddressLength = validations.getMaxAddressLength();
			int maxLandmarkLength = validations.getMaxLandmarkLength();

			if (!StringUtils.isEmpty(address1)) {
				if (address1.length() > maxAddressLength) {
					errors.rejectValue("address1", "Address1 should be not exceed "+maxAddressLength+" characters");
				} else if (!address1.matches(addressRegex)) {
					errors.rejectValue("address1", "Address1 should contain letters,nos, / and - only");
				}
			}
			if (!StringUtils.isEmpty(address2)) {
				if (address2.length() > maxAddressLength) {
					errors.rejectValue("address2", "Address2 should be not exceed "+maxAddressLength+" characters");
				} else if (!address2.matches(addressRegex)) {
					errors.rejectValue("address2", "Address2 should contain letters,nos, / and - only");
				}
			}
			if (!StringUtils.isEmpty(address3)) {
				if (address3.length() > maxAddressLength) {
					errors.rejectValue("address3", "Address3 should be not exceed "+maxAddressLength+" characters");
				} else if (!address3.matches(addressRegex)) {
					errors.rejectValue("address3", "Address3 should contain letters,nos, / and - only");
				}
			}
			if (!StringUtils.isEmpty(landmark)) {
				if (landmark.length() > maxLandmarkLength) {
					errors.rejectValue("landmark", "Landmark should be not exceed "+maxLandmarkLength+" characters");
				} else if (!landmark.matches(addressRegex)) {
					errors.rejectValue("landmark", "Landmark should contain letters,nos, / and - only");
				}
			}

			if (!StringUtils.isEmpty(pincodeValue)) {
				errors.pushNestedPath("pincodeValue");
				ValidationUtils.invokeValidator(pincodeValidator, pincodeValue, errors);
				errors.popNestedPath();
			}

			if (!StringUtils.isEmpty(cityValue)) {
				errors.pushNestedPath("cityValue");
				ValidationUtils.invokeValidator(alphaSpaceValidator, cityValue, errors);
				errors.popNestedPath();
			}

			if (!StringUtils.isEmpty(state)) {
				errors.pushNestedPath("state");
				ValidationUtils.invokeValidator(alphaSpaceValidator, state, errors);
				errors.popNestedPath();
			}
			
			if (!StringUtils.isEmpty(district)) {
				errors.pushNestedPath("district");
				ValidationUtils.invokeValidator(alphaSpaceValidator, district, errors);
				errors.popNestedPath();
			}
		}

	}

}
