package com.fullerton.notificationreport.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@Getter
@Setter
public class EmailConfig {

	@Value("${email.to}")
	private String to;

	@Value("${email.cc}")
	private String cc;

	@Value("${email.subject}")
	private String subject;

	@Value("${email.footer.logo.url}")
	private String footerLogo;

}
