// package com.fullerton.notificationreport.config;
//
// import java.io.File;
// import java.io.IOException;
// import java.util.Properties;
//
// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;
// import
// org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.core.io.ClassPathResource;
// import org.springframework.core.io.FileSystemResource;
// import org.springframework.core.io.Resource;
// import org.springframework.core.io.support.PropertiesLoaderUtils;
//
//// use this if it is required
// @Configuration
// public class PropertyConfigurer {
//
// private static final Logger logger =
// LogManager.getLogger(PropertyConfigurer.class);
//
// private static final String PROPERTY_FOLDER = "CONFIG";
//
// @Bean
// public static PropertyPlaceholderConfigurer properties() throws IOException {
// PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();
// Resource[] resources = new FileSystemResource[] { new FileSystemResource(
// getPropertyFileLocation() + File.separator + PROPERTY_FOLDER + File.separator
// + "email.properties") };
//
// ppc.setLocations(resources);
// ppc.setIgnoreUnresolvablePlaceholders(true);
// return ppc;
// }
//
// public static String getPropertyFileLocation() throws IOException {
// String propertyFileLocation = null;
// Resource resource = new ClassPathResource("application.properties");
// Properties props = null;
// try {
// props = PropertiesLoaderUtils.loadProperties(resource);
// propertyFileLocation = props.getProperty("properties.file.path");
// } catch (IOException e) {
// logger.error(" Exception in resolving properties ", e);
// throw e;
// }
// return propertyFileLocation;
// }
//
// }
