package com.fullerton.notificationreport.service;

public interface DeviceService {

	public long getDeviceCount();

}
