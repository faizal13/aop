package com.fullerton.notificationreport.service;

import java.nio.charset.StandardCharsets;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.util.ArrayUtils;

import com.fullerton.notificationreport.config.EmailConfig;

@Service
public class MailServiceImpl implements MailService {

	@Autowired
	private DeviceService deviceService;

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private SpringTemplateEngine templateEngine;

	@Autowired
	EmailConfig emailConfig;

	@Override
	public void sendReportMail() throws MessagingException {

		// first get count of all devices
		long deviceCount = deviceService.getDeviceCount();
		String footerUrl = emailConfig.getFooterLogo();

		// configure the email
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
				StandardCharsets.UTF_8.name());

		Context context = new Context();
		context.setVariable("deviceCount", deviceCount);
		context.setVariable("footerLogo", footerUrl);
		String html = templateEngine.process("email-template", context);
		helper.setFrom("mohammed.shaikh2@fullertonindia.com");
		helper.setTo(emailConfig.getTo());
		helper.setCc(getAddresses(emailConfig.getCc()));
		// helper.setCc(new InternetAddress[] { new
		// InternetAddress("clover.chitrali.vilas@fullertonindia.com"),
		// new InternetAddress("ajit.shikalgar1@fullertonindia.com") });
		helper.setSubject(emailConfig.getSubject());
		helper.setText(html, true);

		// send the email
		emailSender.send(message);

	}

	private InternetAddress[] getAddresses(String text) throws AddressException {
		String[] addresses = text.split(",");
		InternetAddress[] addressList = null;
		if (!(ArrayUtils.isEmpty(addresses))) {
			for (int i = 0; i < addresses.length; i++) {
				if (addressList == null) {
					addressList = new InternetAddress[addresses.length];
				}
				addressList[i] = new InternetAddress(addresses[i]);
			}
		}

		return addressList;

	}

}
