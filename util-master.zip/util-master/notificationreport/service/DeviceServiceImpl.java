package com.fullerton.notificationreport.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fullerton.notificationreport.dao.DeviceDao;

@Service
public class DeviceServiceImpl implements DeviceService {

	@Autowired
	DeviceDao deviceDao;

	@Override
	public long getDeviceCount() {
		return deviceDao.count();
	}

}
