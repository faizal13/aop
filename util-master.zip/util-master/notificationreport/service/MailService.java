package com.fullerton.notificationreport.service;

import javax.mail.MessagingException;

public interface MailService {

	public void sendReportMail() throws MessagingException;

}
