package com.fullerton.notificationreport.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fullerton.notificationreport.entity.Device;

@Repository
public interface DeviceDao extends CrudRepository<Device, Long> {

}
