package com.fullerton.notificationreport.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Table(name = "device_details")
@Entity
@Getter
@Setter
@ToString
public class Device {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "device_id")
	private long deviceId;

	@Column(name = "imei")
	private String imei;

	@Column(name = "device_secure_id", unique = true)
	private String deviceSecureId;

	@Column(name = "os")
	private String os;

	@Column(name = "device_manufacturer")
	private String deviceManufacturer;

	@Column(name = "device_name")
	private String deviceName;

	@Column(name = "mobile")
	private String mobile;

}
