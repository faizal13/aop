package com.fullerton.uc.pointcut;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class GlobalPointCuts 
{
	@Pointcut(value = "execution(* com.fullerton.uc.utils.APICallUtil.*(..))")
	public void checkApiRequest()
	{
		// comment to satisfy sonarLint		
	}

}
