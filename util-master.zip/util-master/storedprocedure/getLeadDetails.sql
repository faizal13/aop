DELIMITER $$
CREATE DEFINER=`salman`@`%` PROCEDURE `getLeadDetails`(IN type varchar(50),IN employeeId varchar(50))
BEGIN

IF type='pending' THEN

SELECT concat(COALESCE(ud.first_name,'') , COALESCE(ud.middle_name,'') ,COALESCE(ud.last_name,'')) As custName,a.id as id,a.ref_no as refNo,apps.status as status,
			ud.mobile as mobile
			FROM application a  
			join application_status apps on a.application_status_id=apps.id
			join account aes on a.sales_person_id=aes.id 
			join user_detail ud on  
			(ud.id=a.applicant_id)  
			WHERE a.application_status_id in (1,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327)
            and aes.username = employeeId 
		    and ref_no is not null 
			
			and a.created_on BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) and current_date()+1  order by a.id desc;



ELSEIF type='completed' THEN

SELECT concat(COALESCE(ud.first_name,'') , COALESCE(ud.middle_name,''),COALESCE(ud.last_name,'')) As custName,a.id as id,a.ref_no as refNo,apps.status as status
			, ud.mobile as mobile
			FROM application a  
			join application_status apps on a.application_status_id=apps.id
			join account aes on a.sales_person_id=aes.id 
			join user_detail ud on  
			(ud.id=a.applicant_id)  
			WHERE a.application_status_id in (2,400,401,402,403,404,405)
            and aes.username = employeeId 
		    and ref_no is not null 

			and a.created_on BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) and current_date()+1  order by a.id desc;


END IF;

END$$
DELIMITER ;
