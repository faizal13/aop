package com.fullerton.uc.repository;

import com.fullerton.uc.model.LoanDetails;

public interface LoanDetailsRepository extends GenericDao<LoanDetails, Long>{

}
