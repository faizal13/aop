package com.fullerton.uc.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fullerton.uc.model.AllDetailsModel;


@Repository
public class MasterDataRepository 
{
	@Autowired
	EntityManager entityManager;
	
	
	public List<AllDetailsModel> getAllDetails() {

		StoredProcedureQuery procedure = entityManager.createStoredProcedureQuery("getMasterData",
				AllDetailsModel.class);

		@SuppressWarnings("unchecked")
		List<AllDetailsModel> allDetailsList = (List<AllDetailsModel>) procedure.getResultList();

		return allDetailsList;
	}
}
