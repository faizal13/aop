package com.fullerton.uc.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fullerton.uc.model.AllDetailsModel;
import com.fullerton.uc.model.MasterData;
import com.fullerton.uc.repository.MasterDataRepository;

@Service
public class MasterDataService {
	
	@Autowired
	private MasterDataRepository masterDao;
	
	private Logger logger = LogManager.getLogger(this.getClass());
	
	public Map<String, List<MasterData>> getData()
	{
		try {
		List<AllDetailsModel> allDetailsList = masterDao.getAllDetails();
		//System.out.println(allDetailsList);
		List<MasterData> innerMapList = null;
		Map<String, List<MasterData>> outerMap = null;
		MasterData document = null;
		if (!CollectionUtils.isEmpty(allDetailsList)) {
			outerMap = new HashMap<>();
			for(AllDetailsModel obj : allDetailsList) {
				if (!outerMap.isEmpty()) {
					if (!outerMap.containsKey(obj.getId().getTableName())) {
						document = new MasterData();
						innerMapList = new ArrayList<>();
						document.setId(obj.getId().getId());
						document.setCode(obj.getId().getCode());
						document.setName(obj.getId().getName());
						innerMapList.add(document);
						outerMap.put(obj.getId().getTableName(), innerMapList);
					} else {
						document = new MasterData();
						innerMapList = outerMap.get(obj.getId().getTableName());
						document.setId(obj.getId().getId());
						document.setCode(obj.getId().getCode());
						document.setName(obj.getId().getName());
						innerMapList.add(document);
						outerMap.put(obj.getId().getTableName(), innerMapList);
					}

				} else {
					document = new MasterData();
					innerMapList = outerMap.get(obj.getId().getTableName());
					if (innerMapList == null) {
						innerMapList = new ArrayList<>();
					}
					document.setId(obj.getId().getId());
					document.setCode(obj.getId().getCode());
					document.setName(obj.getId().getName());
					innerMapList.add(document);
					outerMap.put(obj.getId().getTableName(), innerMapList);
				}
			}
			//logger.info("outerMap is-->" + outerMap);
			return outerMap;
		} else {
			return null;
		}
		}
		catch(Exception ex)
		{
			logger.info("Exception inside getData-->"+ex);
			return null;
		}
	}
}
