package com.fullerton.uc.repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MobileAvailableRepository {
	@Autowired
	private EntityManager entityManager;

	public Boolean checkDuplicateMobileNumber(Long id, String mobile,Long coApplicantId) {

		StoredProcedureQuery procedure = entityManager.createStoredProcedureQuery("checkMobileNumber");
		procedure.registerStoredProcedureParameter("id", Long.class, ParameterMode.IN);
		procedure.registerStoredProcedureParameter("mobile", String.class, ParameterMode.IN);
		procedure.registerStoredProcedureParameter("coApplicantId", Long.class, ParameterMode.IN);
		procedure.registerStoredProcedureParameter("mobile_exists", Boolean.class, ParameterMode.OUT);

		/*long l = 1086;
		procedure.setParameter("id",l );
		procedure.setParameter("mobile", "9897979797");*/
		
		procedure.setParameter("id", id);
		procedure.setParameter("mobile", mobile);
		procedure.setParameter("coApplicantId", null==coApplicantId?0L:coApplicantId);

		procedure.execute();

		Object obj = procedure.getOutputParameterValue("mobile_exists");
	

		Boolean result = (Boolean) procedure.getOutputParameterValue("mobile_exists");

		return result;

	}

}