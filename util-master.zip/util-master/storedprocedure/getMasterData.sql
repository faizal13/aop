DELIMITER $$
CREATE DEFINER=`tushar`@`%` PROCEDURE `getMasterData`()
BEGIN

select id as 'id', UPPER(name) as 'name', code as 'code','gender' as 'table_name' from gender
union
select id as 'id', UPPER(name) as 'name', code as 'code','maritalStatus' from marrital_status
union
select id as 'id', UPPER(name) as 'name', code as 'code','designation' from designation
union
select id as 'id', UPPER(name) as 'name', code as 'code','coapplicantType' from coapplicant_type
union
select id as 'id', UPPER(name) as 'name', code as 'code','employmentType' from employment_type
union
select id as 'id', UPPER(name) as 'name', code as 'code','natureOfBusiness' from nature_of_business
union
select id as 'id', UPPER(name) as 'name', code as 'code','organization' from organization
union 
select id as 'id', UPPER(name) as 'name', code as 'code','product' from product where active=1
union
select id as 'id', UPPER(name) as 'name', code as 'code','propertyType' from property_type
union
select id as 'id', UPPER(name) as 'name', code as 'code','qualification' from qualification
union
select id as 'id', UPPER(name) as 'name', code as 'code','relation' from relationship
union
select id as 'id', UPPER(name) as 'name', code as 'code','residenceType' from residence_type
union
select id as 'id', UPPER(name) as 'name', code as 'code','sourcingType' from sourcing_type
union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','form60' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
 where dt.name like '%FORM60%'
 
union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','bankPassbookOrStatement' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%BANK PASSBOOK OR STATEMENT%'

union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','businessRegiCert' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%BUSINESS REGISTRATION CERTIFICATE%'

union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','incomeTaxReturns' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%INCOME TAX RETURNS%'
 
union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','salarySlip' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%SALARY SLIP OR CERTIFICATE%'
 
union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','idProof' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%ID PROOF%'
 

union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','addressProof' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%ADDRESS PROOF%'

union
select d.id as 'id', UPPER(d.name) as 'name', d.code as 'code','others' 
from document d join document_type_has_document dthd
on dthd.document_id=d.id 
join document_type dt 
on dthd.document_type_id=dt.id
where dt.name like '%OTHER DOCS_PRE%';






END$$
DELIMITER ;
