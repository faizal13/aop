DELIMITER $$
CREATE DEFINER=`salman`@`%` PROCEDURE `checkMobileNumber`(
    IN  app_id bigint,
    in  mobileno varchar(50),
	IN uid bigint,
    out mobile_exists tinyint)
BEGIN
Declare count_mobile INTEGER;
set @count_mobile =-1;
set @mobile = mobileno;
set @appid = app_id;
set @uid = uid;
set mobile_exists = false;
 
 
select @applicantid:= applicant_id,@coapplicantid1:= coapplicant_id1,@coapplicantid2:= coapplicant_id2,
@coapplicantid3:= coapplicant_id3,@coapplicanti4:= coapplicant_i4,@coapplicantid5:= coapplicant_id5
from hfc_dev.application where id= app_id;

set @query = 'SELECT count(mobile) into @count_mobile FROM hfc_dev.application as a
INNER JOIN hfc_dev.user_detail as u ON a.applicant_id = u.id
or a.coapplicant_id1 = u.id
or a.coapplicant_id2 = u.id
or a.coapplicant_id3 = u.id
or a.coapplicant_i4 = u.id
or a.coapplicant_id5 = u.id 
where u.mobile = @mobile 
AND a.id = @appid';

if(@uid = 0) 
then
set @query = concat(@query, ';');
else
set @query = concat(@query, ' and u.id <> @uid;');
end if; 

PREPARE stmt3 FROM @query;
EXECUTE stmt3;
DEALLOCATE PREPARE stmt3;

if @count_mobile > 0
then set mobile_exists = true;
end if;
END$$
DELIMITER ;
