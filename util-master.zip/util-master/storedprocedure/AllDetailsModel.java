package com.fullerton.uc.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.Table;

@Entity
@Table(name = "all_details_model")
@NamedStoredProcedureQueries({
		@NamedStoredProcedureQuery(name = "getAllDetails", procedureName = "getMasterData", resultClasses = {
				AllDetailsModel.class }) })

public class AllDetailsModel implements Serializable {

	private static final long serialVersionUID = -1574099681334033600L;

	@EmbeddedId
	private AllDetailsId id;

	public AllDetailsId getId() {
		return id;
	}

	public void setId(AllDetailsId id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "AllDetailsModel [id=" + id + "]";
	}

}
