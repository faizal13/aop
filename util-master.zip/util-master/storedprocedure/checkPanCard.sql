DELIMITER $$
CREATE DEFINER=`salman`@`%` PROCEDURE `checkPanCard`(
    IN  app_id bigint,
    in  documentno varchar(50),
	IN uid bigint,
    out pan_exists tinyint)
BEGIN
Declare count_pan INTEGER;
set @count_pan =-1;
set @document_number = documentno;
set @appid = app_id;
set @uid = uid;
set pan_exists = false;
 
 
select @applicantid:= applicant_id,@coapplicantid1:= coapplicant_id1,@coapplicantid2:= coapplicant_id2,
@coapplicantid3:= coapplicant_id3,@coapplicanti4:= coapplicant_i4,@coapplicantid5:= coapplicant_id5
from hfc_dev.application where id= app_id;

set @query = 'SELECT count(document_number) into @count_pan FROM hfc_dev.application as a
INNER JOIN hfc_dev.user_detail as u ON a.applicant_id = u.id INNER JOIN hfc_dev.beauro_detail 
as b on u.beauro_detail_id=b.id
or a.coapplicant_id1 = u.id
or a.coapplicant_id2 = u.id
or a.coapplicant_id3 = u.id
or a.coapplicant_i4 = u.id
or a.coapplicant_id5 = u.id 
where b.document_number = @document_number 
AND a.id = @appid';

if(@uid = 0) 
then
set @query = concat(@query, ';');
else
set @query = concat(@query, ' and u.id <> @uid;');
end if; 

PREPARE stmt4 FROM @query;
EXECUTE stmt4;
DEALLOCATE PREPARE stmt4;

if @count_pan > 0
then set pan_exists = true;
end if;
END$$
DELIMITER ;
