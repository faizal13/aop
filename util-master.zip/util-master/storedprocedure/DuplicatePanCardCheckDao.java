package com.fullerton.uc.repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DuplicatePanCardCheckDao 
{
	@Autowired
	private EntityManager entityManager;

	
	public Boolean checkDuplicatePanCard(Long id, String documentNumber,Long coApplicantId) {

		StoredProcedureQuery procedure = entityManager.createStoredProcedureQuery("checkPanCard");
		procedure.registerStoredProcedureParameter("id", Long.class, ParameterMode.IN);
		procedure.registerStoredProcedureParameter("documentNumber", String.class, ParameterMode.IN);
		procedure.registerStoredProcedureParameter("coApplicantId", Long.class, ParameterMode.IN);
		procedure.registerStoredProcedureParameter("pan_exists", Boolean.class, ParameterMode.OUT);
		procedure.setParameter("id", id);
		procedure.setParameter("documentNumber", documentNumber);
		procedure.setParameter("coApplicantId", null==coApplicantId?0L:coApplicantId);

		procedure.execute();

		return (Boolean) procedure.getOutputParameterValue("pan_exists");

	}



}
