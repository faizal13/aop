DELIMITER $$
CREATE DEFINER=`tushar`@`%` PROCEDURE `procUpdateMaster`(
	in paramMasterType varchar(50)
)
begin
	declare modifiedCount int default 0;

	drop temporary table if exists tempMaster;
	
	create temporary table tempMaster
	(
		id int primary key,
		code varchar(75),
		description varchar(300),
		masterType varchar(50),
        status varchar(1),
		createdBy varchar(20),
		createdOn datetime,
		modifiedBy varchar(20),
		modifiedOn datetime
	);
    
    drop temporary table if exists tempPincodeMaster;
    
    create temporary table tempPincodeMaster (
		id int primary key,
		pincode varchar(10),
		cityId varchar(10),
		city varchar(75),
		stateId varchar(10),
		state varchar(100),
		districtId varchar(10),
		district varchar(100),
		status varchar(1),
		createdBy varchar(20),
		createdOn datetime,
		modifiedBy varchar(20),
		modifiedOn datetime
	);
    
    drop temporary table if exists tempBranchMapping;
    
    create temporary table tempBranchMapping (
		id int primary key,
		city varchar(75),
		productKey varchar(50),
		name varchar(200),
		territoryCode varchar(50),
		territoryKey varchar(50),
		tier varchar(75),
		servicingBranch varchar(200),
		status varchar(1),
		createdBy varchar(20),
		createdOn datetime,
		modifiedBy varchar(20),
		modifiedOn datetime
	);
    
	insert into tempMaster(id, code, description, masterType, createdBy, createdOn, modifiedBy, modifiedOn, status)
		select id, trim(code), description, trim(masterType), createdBy, createdOn, modifiedBy, modifiedOn, status 
		from master where status='I';
        
	update master 
    	inner join tempMaster on master.id=tempMaster.id 
		set master.status='P' 
    	where tempMaster.status='I';
       
	insert into tempBranchMapping(id, city, productKey, name, territoryCode, territoryKey, tier, servicingBranch,
	status, createdBy, createdOn, modifiedBy, modifiedOn)
		select id, city, productKey, name, territoryCode, territoryKey, tier, servicingBranch,
		status, createdBy, createdOn, modifiedBy, modifiedOn from branchMapping where status='I';
	
	update branchMapping
	inner join tempBranchMapping on branchMapping.id=tempBranchMapping.id
		set branchMapping.status='P'
	where tempBranchMapping.status='I';
 
	insert into tempPincodeMaster(id, pincode, cityId, city, stateId, state, districtId, district, 
		status,createdBy, createdOn, modifiedBy, modifiedOn)
		select id, pincode,  cityId, city, stateId, state, districtId, district, 
		status, createdBy, createdOn, modifiedBy, modifiedOn from pincodeMaster where status='I';
        
	update pincodeMaster
	inner join tempPincodeMaster on pincodeMaster.id=tempPincodeMaster.id
		set pincodeMaster.status='P'
	where tempPincodeMaster.status='I';
	
    if (paramMasterType = 'all' or paramMasterType='' or paramMasterType is null) then
	begin		
        /* update in case code is available -Melroy 27/Nov/2018 */
		update tempMaster inner join gender on tempMaster.code=gender.code
		and tempMaster.description=gender.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='gender' and status='I';
        
		update gender inner join tempMaster on gender.code=tempMaster.code 
			set gender.name=tempMaster.description, gender.active=1, 
			gender.modified_by='system', gender.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='gender' and status='I';
        
		update tempMaster inner join designation on tempMaster.code=designation.code
		and tempMaster.description=designation.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='designation' and status='I';
        
		update designation inner join tempMaster on designation.code=tempMaster.code 
			set designation.name=tempMaster.description, 
			designation.modified_by='system', designation.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='designation' and status='I';
        
		update tempMaster inner join qualification on tempMaster.code=qualification.code
		and qualification.name=tempMaster.description
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Qualification' and status='I';
        
		update qualification inner join tempMaster on qualification.code=tempMaster.code 
			set qualification.name=tempMaster.description, 
        	qualification.modified_by='system', qualification.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Qualification' and status='I';
        
	        /*update tempMaster inner join preferred_mailing_address_master 
		on preferred_mailing_address_master.code=tempMaster.code
		and tempMaster.description=preferred_mailing_address_master.value
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Preferred Mailing address' and status='I';
        
        	update preferred_mailing_address_master inner join tempMaster on preferred_mailing_address_master.code=tempMaster.code 
			set preferred_mailing_address_master.value=tempMaster.description, 
            	preferred_mailing_address_master.modified_by='system', preferred_mailing_address_master.modified_on=now(), status='P'
		where tempMaster.masterType='Preferred Mailing address' and status='I';
		*/

		update tempMaster inner join organization on tempMaster.code=organization.code
		and tempMaster.description=organization.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Organization' and status='I';

		update organization inner join tempMaster on organization.code=tempMaster.code 
			set organization.name=tempMaster.description, organization.active=1,
			organization.modified_by='system', organization.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Organization' and status='I';
        
        update tempMaster inner join nature_of_business on tempMaster.code=nature_of_business.code
		and tempMaster.description=nature_of_business.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Nature of Business' and status='I';
        
	    update nature_of_business inner join tempMaster on nature_of_business.code=tempMaster.code 
			set nature_of_business.name=tempMaster.description, 
       		nature_of_business.modified_by='system', nature_of_business.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Nature of Business' and status='I';

		update tempMaster inner join marrital_status on tempMaster.code=marrital_status.code
		and tempMaster.description=marrital_status.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Marital Status' and status='I';
        
		update marrital_status inner join tempMaster on marrital_status.code=tempMaster.code 
			set marrital_status.name=tempMaster.description, marrital_status.active=1, 
		marrital_status.modified_by='system', marrital_status.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Marital Status' and status='I';
        /*
		update tempMaster inner join program_variant on tempMaster.code=program_variant.code
		and tempMaster.description=program_variant.name
            		set tempMaster.status='F'
		where trim(tempMaster.masterType)='Program Variant';*/
        
		/*update program_variant inner join tempMaster on program_variant.code=tempMaster.code 
			set program_variant.name=tempMaster.description, 
		program_variant.modified_by='system', program_variant.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Program Variant' and status='I';*/

		/*update tempMaster inner join program_type on tempMaster.code=program_type.code
		and tempMaster.description=program_type.name
            		set tempMaster.status='F'
		where trim(tempMaster.masterType)='Program Type' and status='I';*/
        
		/*update program_type inner join tempMaster on program_type.code=tempMaster.code 
			set program_type.name=tempMaster.description, program_type.active=1, 
		program_type.modified_by='system', program_type.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Program Type' and status='I';
        */
		update tempPincodeMaster inner join pincode_master on tempPincodeMaster.pincode=pincode_master.pincode
		and tempPincodeMaster.city=pincode_master.city and tempPincodeMaster.state=pincode_master.state
		and tempPincodeMaster.district=pincode_master.district
			set tempPincodeMaster.status='F'
		where tempPincodeMaster.status='I';
        
		update pincode_master inner join tempPincodeMaster on pincode_master.pincode=tempPincodeMaster.pincode 
			set pincode_master.city=tempPincodeMaster.city, pincode_master.state=tempPincodeMaster.state, 
	      	pincode_master.district=tempPincodeMaster.district, pincode_master.modified_by='system', 
			pincode_master.modified_on=now(), tempPincodeMaster.status='P'
		where tempPincodeMaster.status='I';
        
		update tempMaster inner join employment_type on tempMaster.code=employment_type.code
		and tempMaster.description=employment_type.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Employment Type' and status='I';
        
		update employment_type inner join tempMaster on employment_type.code=tempMaster.code
			set employment_type.name=tempMaster.description, employment_type.active=1,
			employment_type.modified_by='system', employment_type.modified_on=now(),
			tempMaster.status='P'
		where trim(tempMaster.masterType)='Employment Type' and status='I';
       		
		update tempMaster inner join property_type on tempMaster.code=property_type.code
		and tempMaster.description=property_type.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Property Type' and tempMaster.status='I';		

		update property_type inner join tempMaster on property_type.code=tempMaster.code
			set property_type.name=tempMaster.description, property_type.modified_by='system',
			property_type.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Property Type' and tempMaster.status='I';

		update tempMaster inner join channel on tempMaster.code=channel.code
		and tempMaster.description=channel.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Channel Master' and tempMaster.status='I';
        
		update channel inner join tempMaster on channel.code=tempMaster.code
			set channel.name=tempMaster.description, channel.modified_by='system',
			channel.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Channel Master' and tempMaster.status='I';

		update tempMaster inner join residence_type on tempMaster.code=residence_type.code
		and tempMaster.description=residence_type.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Residence Type' and tempMaster.status='I';
            
		update residence_type inner join tempMaster on residence_type.code=tempMaster.code
			set residence_type.name=tempMaster.description, residence_type.modified_by='system',
			residence_type.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Residence Type' and tempMaster.status='I';

		update tempMaster inner join relationship on tempMaster.code=relationship.code
		and tempMaster.description=relationship.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Relationship' and tempMaster.status='I';
        
		update relationship inner join tempMaster on relationship.code=tempMaster.code
			set relationship.name=tempMaster.description, relationship.modified_by='system',
			relationship.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Relationship' and tempMaster.status='I';

		update tempMaster inner join coapplicant_type on tempMaster.code=coapplicant_type.code
		and tempMaster.description=coapplicant_type.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Co-Applicant Type' and tempMaster.status='I';
        
        update coapplicant_type inner join tempMaster on coapplicant_type.code=tempMaster.code
			set coapplicant_type.name=tempMaster.description, coapplicant_type.modified_by='system',
			coapplicant_type.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Co-Applicant Type' and tempMaster.status='I';

		update tempMaster inner join product on tempMaster.code=product.code
		and tempMaster.description=product.name
			set tempMaster.status='F'
		where trim(tempMaster.masterType)='Product' and tempMaster.status='I';
        
        update product inner join tempMaster on product.code=tempMaster.code
			set product.name=tempMaster.description, product.modified_by='system',
			product.modified_on=now(), status='P'
		where trim(tempMaster.masterType)='Product' and tempMaster.status='I';
        
		update branch_user_mapping inner join tempBranchMapping on branch_user_mapping.sales_product_key=tempBranchMapping.productKey
		and branch_user_mapping.territory_key=tempBranchMapping.territoryKey 
			set branch_user_mapping.sales_city=tempBranchMapping.city, branch_user_mapping.sales_product_name=tempBranchMapping.name, 
			branch_user_mapping.territory_code=tempBranchMapping.territoryCode,
			branch_user_mapping.servicing_branch_name=tempBranchMapping.servicingBranch, branch_user_mapping.tier=tempBranchMapping.tier,
			branch_user_mapping.active=1, branch_user_mapping.modified_by='system', branch_user_mapping.modified_on=now(), status='P'
		where status='I';

		insert into gender(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='gender' and status='I';

		insert into designation(code, name, created_by, created_on)
			select code, description, 'system', now() from tempMaster where trim(masterType)='designation' and status='I';
		
		insert into qualification(code, name, created_by, created_on)
			select code, description, 'system', now() from tempMaster where trim(masterType)='Qualification' and status='I';
		
		/*
        	insert into preferred_mailing_address_master(code, value, created_by, created_on)
			select code, description, 'system', now() from tempMaster where trim(masterType)='Preferred Mailing address' and status='I';            
		*/

		insert into organization(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType) like 'Organization' and status='I';

		insert into nature_of_business(code, name, created_by, created_on)
			select code, description, 'system', now() from tempMaster where trim(masterType)='Nature of Business' and status='I';	

		insert into marrital_status(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Marital Status' and status='I';
            
		/*insert into program_variant(code, name, created_by, created_on)
			select code, description, 'system', now() from tempMaster where trim(masterType)='Program Variant' and status='I';

		insert into program_type(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Program Type' and status='I';*/
            
		insert into employment_type(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Employment Type' and status='I';
            	
		insert into property_type(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Property Type' and status='I';
		
        insert into channel(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Channel Master' and status='I';

        insert into residence_type(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Residence Type' and status='I';
         
		insert into relationship(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Relationship' and status='I';
            
		insert into coapplicant_type(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Co-Applicant Type' and status='I';

		insert into product(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Product' and status='I';

		insert into pincode_master(pincode, city, state, district, created_by, created_on)
			select pincode, city, state, district, 'system', now() from tempPincodeMaster where status='I';
            
		insert into branch_user_mapping(sales_city, sales_product_key, sales_product_name, territory_key, territory_code, tier,
			servicing_branch_name, active, created_by, created_on, modified_by, modified_on)
			select city, productKey, name, territoryKey, territoryCode, tier, servicingBranch, 
			1, createdBy, createdOn, modifiedBy, modifiedOn
			from tempBranchMapping where status='I';
            
		update master
		inner join tempMaster on master.id=tempMaster.id
			set master.status=case 
				when(tempMaster.status='S') then 'S' 
				when(tempMaster.status='I') then 'S'
                when(tempMaster.status='P') then 'S'
                when(tempMaster.status='F') then 'F'
			else 'E' end, 
	   	master.modifiedBy='system', master.modifiedOn=now()
		where master.id=tempMaster.id and master.status ='P'; 
        
		update pincodeMaster
		inner join tempPincodeMaster on pincodeMaster.id=tempPincodeMaster.id
			set pincodeMaster.status=case 
				when(tempPincodeMaster.status='S') then 'S' 
				when(tempPincodeMaster.status='I') then 'S'
                when(tempPincodeMaster.status='P') then 'S'
                when(tempPincodeMaster.status='F') then 'F'
			else 'E' end, 
            pincodeMaster.modifiedBy='system', pincodeMaster.modifiedOn=now()
		where pincodeMaster.id=tempPincodeMaster.id and pincodeMaster.status='P';
        
		update branchMapping
		inner join tempBranchMapping on branchMapping.productKey=tempBranchMapping.productKey
	        and branchMapping.territoryCode=tempBranchMapping.territoryCode and branchMapping.territoryKey=tempBranchMapping.territoryKey
			set branchMapping.status='S', branchMapping.modifiedBy='system', branchMapping.modifiedOn=now()
		where branchMapping.id=tempBranchMapping.id and branchMapping.status='P';
        
		insert into master_log(lastModifiedOn)
			select coalesce(master.createdOn,master.modifiedOn) from master
			inner join tempMaster on master.id=tempMaster.id where master.status='S'
				union
            		select coalesce(pincodeMaster.createdOn,pincodeMaster.modifiedOn) from pincodeMaster
			inner join tempPincodeMaster on pincodeMaster.id=tempPincodeMaster.id
			where pincodeMaster.id=tempPincodeMaster.id and pincodeMaster.status='S'
            	union
			select coalesce(branchMapping.createdOn,branchMapping.modifiedOn) from branchMapping
			inner join tempBranchMapping on branchMapping.id=tempBranchMapping.id
			and branchMapping.territoryCode=tempBranchMapping.territoryCode 
            		and branchMapping.territoryKey=tempBranchMapping.territoryKey
			where branchMapping.id=tempBranchMapping.id and branchMapping.status='S' limit 1;
	end;
    else
    begin
	case 
		when (paramMasterType='gender') then
		begin
			update tempMaster inner join gender on tempMaster.code=gender.code
			and tempMaster.description=gender.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='gender' and status='I';
       
			update gender inner join tempMaster on gender.code=tempMaster.code 
				set gender.name=tempMaster.description, gender.active=1, 
			gender.modified_by='system', gender.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='gender' and status='I';
				
			insert into gender(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='gender' and status='I';
		end;
        when (paramMasterType='designation') then
		begin
			update tempMaster inner join designation on designation.code=tempMaster.code
			and tempMaster.description=designation.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='designation' and status='I';
        
			update designation inner join tempMaster on designation.code=tempMaster.code 
				set designation.name=tempMaster.description, 
			designation.modified_by='system', designation.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='designation' and status='I';
                
			insert into designation(code, name, created_by, created_on)
				select code, description, 'system', now() from tempMaster where trim(masterType)='designation' and status='I';
		end;
		when (paramMasterType='qualification') then
		begin
			update tempMaster inner join qualification on tempMaster.code=qualification.code
				and qualification.name=tempMaster.description
					set tempMaster.status='F'
			where trim(tempMaster.masterType)='Qualification' and status='I';
        
			update qualification inner join tempMaster on qualification.code=tempMaster.code 
				set qualification.name=tempMaster.description, 
			qualification.modified_by='system', qualification.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Qualification' and status='I';
				
			insert into qualification(code, name, created_by, created_on)
				select code, description, 'system', now() from tempMaster where trim(masterType)='Qualification' and status='I';
		end;
		/*when (paramMasterType='preferred_mailing_address') then
		begin
			update tempMaster 
			inner join preferred_mailing_address_master on preferred_mailing_address_master.code=tempMaster.code
			and tempMaster.description=preferred_mailing_address_master.value
					set tempMaster.status='F'
			where trim(tempMaster.masterType)='Preferred Mailing address' and status='I';
        
				update preferred_mailing_address_master inner join tempMaster on preferred_mailing_address_master.code=tempMaster.code 
					set preferred_mailing_address_master.value=tempMaster.description, 
				preferred_mailing_address_master.modified_by='system', preferred_mailing_address_master.modified_on=now(), status='P'
				where tempMaster.masterType='Preferred Mailing address' and status='I';
                
                insert into preferred_mailing_address_master(code, value, created_by, created_on)
					select code, description, 'system', now() from tempMaster where trim(masterType)='Preferred Mailing address' and status='I';
		end;*/
		when (paramMasterType='organization') then
		begin
			update tempMaster inner join organization on tempMaster.code=organization.code
			and tempMaster.description=organization.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Organization' and status='I';
                
			update organization inner join tempMaster on organization.code=tempMaster.code 
				set organization.name=tempMaster.description, organization.active=1,
			organization.modified_by='system', organization.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Organization' and status='I';
			
			insert into organization(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster 
				where trim(masterType) like 'Organization' and status='I';
		end;
		when (paramMasterType='nature_of_business') then
		begin
			update tempMaster inner join nature_of_business on tempMaster.code=nature_of_business.code
			and tempMaster.description=nature_of_business.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Nature of Business' and status='I';
        
			update nature_of_business inner join tempMaster on nature_of_business.code=tempMaster.code 
				set nature_of_business.name=tempMaster.description, 
			nature_of_business.modified_by='system', nature_of_business.modified_on=now(), status='P'
				where trim(tempMaster.masterType)='Nature of Business' and status='I';
        
			insert into nature_of_business(code, name, created_by, created_on)
				select code, description, 'system', now() from tempMaster 
				where trim(masterType)='Nature of Business' and status='I';
		end;
		when (paramMasterType='marital_status') then
		begin
			update tempMaster inner join marrital_status on tempMaster.code=marrital_status.code
			and tempMaster.description=marrital_status.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Marital Status' and status='I';
        
			update marrital_status inner join tempMaster on marrital_status.code=tempMaster.code 
				set marrital_status.name=tempMaster.description, marrital_status.active=1, 
			marrital_status.modified_by='system', marrital_status.modified_on=now(), status='P'
			where tempMaster.masterType='Marital Status' and status='I';
                
			insert into marrital_status(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster 
				where trim(masterType)='Marital Status' and status='I';
		end;
		/*when (paramMasterType='programVariant') then
            	begin
			update tempMaster inner join program_variant on tempMaster.code=program_variant.code
			and tempMaster.description=program_variant.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Program Variant';
        
			update program_variant inner join tempMaster on program_variant.code=tempMaster.code 
				set program_variant.name=tempMaster.description, 
			program_variant.modified_by='system', program_variant.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Program Variant' and status='I';
                
			insert into program_variant(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Program Variant' and status='I';
            	end;
            	when (paramMasterType='programType') then
            	begin
			update tempMaster inner join program_type on tempMaster.code=program_type.code
			and tempMaster.description=program_type.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Program Type' and status='I';
        
			update program_type inner join tempMaster on program_type.code=tempMaster.code 
				set program_type.name=tempMaster.description, program_type.active=1, 
			program_type.modified_by='system', program_type.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Program Type' and status='I';
                
			insert into program_type(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Program Type' and status='I';
		end;*/
		when (paramMasterType='employmentType') then
		begin
			update tempMaster inner join employment_type on tempMaster.code=employment_type.code
			and tempMaster.description=employment_type.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Employment Type' and status='I';
        
			update employment_type inner join tempMaster on employment_type.code=tempMaster.code
				set employment_type.name=tempMaster.description, employment_type.active=1,
			employment_type.modified_by='system', employment_type.modified_on=now(),
                    	tempMaster.status='P'
			where trim(tempMaster.masterType)='Employment Type' and status='I';
                
                	insert into employment_type(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster 
				where trim(masterType)='Employment Type' and status='I';
		end;
		when (paramMasterType='propertyType') then
		begin
			update tempMaster inner join property_type on tempMaster.code=property_type.code
			and tempMaster.description=property_type.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Property Type' and status='I';

			update property_type inner join tempMaster on property_type.code=tempMaster.code
				set property_type.name=tempMaster.description, modifiedBy='system', modifiedOn=now(),
				active=1, tempMaster.status='P'
			where trim(tempMaster.masterType)='Property Type' and status='I';

			insert into property_type(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster
				where trim(masterType)='Property Type' and status='I';
		end;
        when (paramMasterType='channel') then
		begin
			update tempMaster inner join channel on tempMaster.code=channel.code
			and tempMaster.description=channel.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Channel Master' and tempMaster.status='I';
        
			update channel inner join tempMaster on channel.code=tempMaster.code
				set channel.name=tempMaster.description, channel.modified_by='system',
				channel.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Channel Master' and tempMaster.status='I';
            
			insert into channel(code, name, active, created_by, created_on)
			select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Channel Master' and status='I';
        end;
        when (paramMasterType='residenceType') then
        begin
			update tempMaster inner join residence_type on tempMaster.code=residence_type.code
			and tempMaster.description=residence_type.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Residence Type' and tempMaster.status='I';
        
			update tempMaster inner join channel on tempMaster.code=residence_type.code
			and tempMaster.description=residence_type.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Residence Type' and tempMaster.status='I';
        
			update residence_type inner join tempMaster on residence_type.code=tempMaster.code
				set residence_type.name=tempMaster.description, residence_type.modified_by='system',
				residence_type.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Residence Type' and tempMaster.status='I';
            
			insert into residence_type(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Residence Type' and status='I';
        end;
        when (paramMasterType='relationship') then
        begin
			update tempMaster inner join relationship on tempMaster.code=relationship.code
			and tempMaster.description=relationship.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Relationship' and tempMaster.status='I';

			update relationship inner join tempMaster on relationship.code=tempMaster.code
				set relationship.name=tempMaster.description, relationship.modified_by='system',
				relationship.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Relationship' and tempMaster.status='I';
            
            insert into relationship(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Relationship' and status='I';
        end;
		when (paramMasterType='coApplicantType') then
        begin
			update tempMaster inner join coapplicant_type on tempMaster.code=coapplicant_type.code
			and tempMaster.description=coapplicant_type.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Co-Applicant Type' and tempMaster.status='I';
        
			update coapplicant_type inner join tempMaster on coapplicant_type.code=tempMaster.code
				set coapplicant_type.name=tempMaster.description, coapplicant_type.modified_by='system',
				coapplicant_type.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Co-Applicant Type' and tempMaster.status='I';
            
            insert into coapplicant_type(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Co-Applicant Type' and status='I';
        end;
        when (paramMasterType='product') then
        begin
			update tempMaster inner join product on tempMaster.code=product.code
			and tempMaster.description=product.name
				set tempMaster.status='F'
			where trim(tempMaster.masterType)='Product' and tempMaster.status='I';
        
			update product inner join tempMaster on product.code=tempMaster.code
				set product.name=tempMaster.description, product.modified_by='system',
				product.modified_on=now(), status='P'
			where trim(tempMaster.masterType)='Product' and tempMaster.status='I';
            
			insert into product(code, name, active, created_by, created_on)
				select code, description, 1, 'system', now() from tempMaster where trim(masterType)='Product' and status='I';
        end;
		when (paramMasterType='pincode') then
		begin
			/*update pincodeMaster inner join pincode_master on pincodeMaster.pincode=pincode_master.pincode
			and pincodeMaster.city=pincode_master.city and pincodeMaster.state=pincode_master.state
			and pincodeMaster.district=pincode_master.district
				set pincodeMaster.status='F'
			where status='I';
        
			update pincode_master inner join pincodeMaster on pincode_master.pincode=pincodeMaster.pincode 
				set pincode_master.city=pincodeMaster.city, pincode_master.state=pincodeMaster.state, 
			pincode_master.district=pincodeMaster.district, pincode_master.modified_by='system', 
			pincode_master.modified_on=now(), status='P'
			where status='I';*/
			
			update tempPincodeMaster inner join pincode_master on tempPincodeMaster.pincode=pincode_master.pincode
			and tempPincodeMaster.city=pincode_master.city and tempPincodeMaster.state=pincode_master.state
			and tempPincodeMaster.district=pincode_master.district
				set tempPincodeMaster.status='F'
			where tempPincodeMaster.status='I';
        
			update pincode_master inner join tempPincodeMaster on pincode_master.pincode=tempPincodeMaster.pincode 
				set pincode_master.city=tempPincodeMaster.city, pincode_master.state=tempPincodeMaster.state, 
				pincode_master.district=tempPincodeMaster.district, pincode_master.modified_by='system', 
				pincode_master.modified_on=now(), tempPincodeMaster.status='P'
			where tempPincodeMaster.status='I';
                
			insert into pincode_master(pincode, city, state, district, created_by, created_on)
				select pincode, city, state, district, createdBy, createdOn from tempPincodeMaster where status='I';
		end;
		when (paramMasterType='branchMapping') then
		begin
			update branch_user_mapping inner join tempBranchMapping on branch_user_mapping.sales_product_key=tempBranchMapping.productKey
			and branch_user_mapping.territory_key=tempBranchMapping.territoryKey 
				set branch_user_mapping.sales_city=tempBranchMapping.city, branch_user_mapping.sales_product_name=tempBranchMapping.name, 
			branch_user_mapping.territory_code=tempBranchMapping.territoryCode,
			branch_user_mapping.servicing_branch_name=tempBranchMapping.servicingBranch, branch_user_mapping.tier=tempBranchMapping.tier,
			branch_user_mapping.active=1, branch_user_mapping.modified_by='system', branch_user_mapping.modified_on=now(), status='P'
			where status='I' and branch_user_mapping.sales_product_name<>tempBranchMapping.name;
				
			insert into branch_user_mapping(sales_city, sales_product_key, sales_product_name, territory_key, territory_code, tier,
			servicing_branch_name, active, created_by, created_on, modified_by, modified_on)
				select city, productKey, name, territoryKey, territoryCode, tier, servicingBranch, 
				1, createdBy, createdOn, modifiedBy, modifiedOn
				from tempBranchMapping where status='I';
		end;
	end case;
        
	update master
	inner join tempMaster on master.id=tempMaster.id
		set master.status=case when(tempMaster.status='S') then 'S' 
				when(tempMaster.status='I') then 'S'
                when(tempMaster.status='P') then 'S'
                when(tempMaster.status='F') then 'F'
			else 'E' end, 
    	master.modifiedBy='system', master.modifiedOn=now()
	where master.id=tempMaster.id and master.status ='I';
        
		update pincodeMaster
		inner join tempPincodeMaster on pincodeMaster.id=tempPincodeMaster.id
			set pincodeMaster.status=case 
				when(tempPincodeMaster.status='S') then 'S' 
				when(tempPincodeMaster.status='I') then 'S'
                when(tempPincodeMaster.status='P') then 'S'
                when(tempPincodeMaster.status='F') then 'F'
			else 'E' end, 
            pincodeMaster.modifiedBy='system', pincodeMaster.modifiedOn=now()
		where pincodeMaster.id=tempPincodeMaster.id and pincodeMaster.status='P';
        
    update branchMapping
	inner join tempBranchMapping on branchMapping.productKey=tempBranchMapping.productKey
        and branchMapping.territoryCode=tempBranchMapping.territoryCode and branchMapping.territoryKey=tempBranchMapping.territoryKey
		set branchMapping.status='S', branchMapping.modifiedBy='system', branchMapping.modifiedOn=now()
	where branchMapping.id=tempBranchMapping.id and branchMapping.status='I';
        
	insert into master_log(lastModifiedOn)
		select coalesce(master.createdOn,master.modifiedOn) from master
			inner join tempMaster on master.id=tempMaster.id where master.status='S'
      	union
		select coalesce(pincodeMaster.createdOn,pincodeMaster.modifiedOn) from pincodeMaster
			inner join tempPincodeMaster on pincodeMaster.id=tempPincodeMaster.id
		where pincodeMaster.id=tempPincodeMaster.id and pincodeMaster.status='S'
        union
		select coalesce(branchMapping.createdOn,branchMapping.modifiedOn) from branchMapping
			inner join tempBranchMapping on branchMapping.id=tempBranchMapping.id
		and branchMapping.territoryCode=tempBranchMapping.territoryCode 
     	and branchMapping.territoryKey=tempBranchMapping.territoryKey
		where branchMapping.id=tempBranchMapping.id and branchMapping.status='S' limit 1;
    	end;
	end if;
end$$
DELIMITER ;
