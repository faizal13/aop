package utils;

import java.util.Map;

public class ApiCallResponse {
	
	private int statusCode;
	
	private String responseBody;
	
	private Map<String, String> headers;

	ApiCallResponse(int statusCode, String responseBody, Map<String, String> headers) {
		this.statusCode = statusCode;
		this.responseBody = responseBody;
		this.headers = headers;
	}

	public static ApiCallResponseBuilder builder() {
		return new ApiCallResponseBuilder();
	}

	public int getStatusCode() {
		return this.statusCode;
	}

	public String getResponseBody() {
		return this.responseBody;
	}

	public Map<String, String> getHeaders() {
		return this.headers;
	}

	public String toString() {
		return "ApiCallResponse(statusCode=" + this.getStatusCode() + ", responseBody=" + this.getResponseBody() + ", headers=" + this.getHeaders() + ")";
	}

	public static class ApiCallResponseBuilder {
		private int statusCode;
		private String responseBody;
		private Map<String, String> headers;

		ApiCallResponseBuilder() {
		}

		public ApiCallResponse.ApiCallResponseBuilder statusCode(int statusCode) {
			this.statusCode = statusCode;
			return this;
		}

		public ApiCallResponse.ApiCallResponseBuilder responseBody(String responseBody) {
			this.responseBody = responseBody;
			return this;
		}

		public ApiCallResponse.ApiCallResponseBuilder headers(Map<String, String> headers) {
			this.headers = headers;
			return this;
		}

		public ApiCallResponse build() {
			return new ApiCallResponse(statusCode, responseBody, headers);
		}

		public String toString() {
			return "ApiCallResponse.ApiCallResponseBuilder(statusCode=" + this.statusCode + ", responseBody=" + this.responseBody + ", headers=" + this.headers + ")";
		}
	}
}
